using Random

 
#---- Point structure: In 2D space with Euclidian distance ----#
struct Point
    x::Float64
    y::Float64
end
distance(point1::Point, point2::Point) = sqrt((point1.x-point2.x)^2 + (point1.y-point2.y)^2)

#---- Visit structure: pair of (client,hour) ----#
struct Visit
    client::Int
    hours::Float64
end
getClient(visit::Visit) = visit.client
getHours(visit::Visit) = visit.hours

#---- Plan structure: a day and a list of visits ----# #To be deleted by KAI
struct Plan
    day::Int
    visits::Vector{Visit}
end
getClients(p::Plan) = getClient.(p.visits)
 

#---- Plan structure: a day and a list of visits ----#Kai
struct PlanTSP
    day::Int
    cost::Float64
    visits::Vector{Visit}
end
getClients(p::PlanTSP) = getClient.(p.visits)

#---- Plan structure: a day and a list of visits for plan-based pricing problem ----#Kai
struct PlanTSP_PP
    day::Int
    cost::Float64 ### tavel time
    visits::Vector{Visit}
    workloadD::Float64 ### total workload 
    in_set::Int  ### total workload in discretized unit
    totcost::Float64 ### total travel and workload cost
    rdcost::Float64 ### reduced cost
    routeind::Int ### index of route
end
getClients(p::PlanTSP_PP) = getClient.(p.visits)

#---- Route structure: a day and a list of visits ----#Kai
struct RouteP
    cost::Float64
    visits::Vector{Visit}
end
getClients(p::RouteP) = getClient.(p.visits)
######################################################

#----- Instance of the problem ----#
struct Instance
    n::Int
    K::Int
    D::Int
    maxHours::Int
    workNeeded::Vector{Float64}
    clientDays::Array{Int,2}
    timeTravel::Array{Float64,2}
    wages::Array{Array{Float64,1},1}
    c_T::Float64
    c_W::Float64
end

"""
    Generates a uniformly random point in a L2 disk.
"""
function random_point_in_disk(radius)
    x,y = (rand()-0.5)*2,(rand()-0.5)*2
    while x^2+y^2 > 1
        x,y = (rand()-0.5)*2,(rand()-0.5)*2
    end
    return Point(radius*x, radius*y)
end

"""
        Creates a random instance of the problem, in a Euclidian space with realistic parameters
"""
function createInstance(
    customers, # number of customers to serve
    vehicles,  # number of vehicles available
    days;      # number of days to plan
        max_travel_time_from_depot = 1., # this parameter controls the travel times, it's the radius of the area
        setup_time=0.75, # time it takes to setup a vehicle before it can work, when arriving at a customer.
        minimum_customer_work=4, # minimum work hours needed to serve a customer 
        maximum_customer_work=10, # maximum work hours needed to serve a customer 
        minimum_customer_availability=2,
        maximum_customer_availability=4, # maximum length of the interval of days each customer is available
        wages=[[20,0], [22,16], [24,33], [26,51], [28,70], [30,90], [32,111], [34,133], [36,156], [38,180], [40,205]], # the following parameters describe the costs and availability of vehicles and labor: [20,0], [30,80], [40,200]
        c_T=22.5,
        c_W=10.35,
        max_hours=14,
        #field_work=4,  #to be deleted!!!!!!!!!!!!!!!!!!!!!
)    
    # generate the field locations, uniformly randomly in a disk centered on the depot (L2 norm)
    customers_location = [random_point_in_disk(max_travel_time_from_depot) for i in 1:customers]
    
    # Generate travel times using euclidian distance and including setup time
    traveltime = zeros((customers+2,customers+2)) # indices 1 and n+2 represent the depot, used as a origin or destination
    locations = [Point(0,0); customers_location; Point(0,0)]
    for (i, loc1) in enumerate(locations) # get index and location of each customer
        for (j, loc2) in enumerate(locations)
            if (j!=customers+2) && (i!=j) # if we are going to a customer, we need to add the setup time.
                traveltime[i,j] = distance(loc1,loc2) + setup_time
            else
                traveltime[i,j] = distance(loc1,loc2) 
            end
        end
    end
    
    # work demand is generated uniformly between minimum_customer_work and maximum_customer_work
    customer_work = rand(customers).*(maximum_customer_work-minimum_customer_work) .+ minimum_customer_work
    
#=     ##########new way of generating instances. to be deleted, and release above # for value of sharing
    minimum_customer_work = field_work*0.7
    maximum_customer_work = field_work*0.3
    customer_work = rand(Int(floor(customers/2))).*(maximum_customer_work-minimum_customer_work) .+ minimum_customer_work
    minimum_customer_work = field_work*1.3
    maximum_customer_work = field_work*1.7
    customer_work1 = rand(customers-Int(floor(customers/2))).*(maximum_customer_work-minimum_customer_work) .+ minimum_customer_work
    append!(customer_work,customer_work1) =#

    # the number of days each customer is available (uniform distribution between minimum_customer_availability and maximum_customer_availability)
    customer_available_days = rand(minimum_customer_availability:maximum_customer_availability, customers)
    
    # we now fill a matrix with 1s when a customer is available a given day, 0 otherwise
    #customer_days = zeros(Int,customers, days)
    #for customer in 1:customers
        #total_days = customer_available_days[customer]
        #first_day = rand(1:days)
        #for day in first_day:(first_day+total_days-1)
            #customer_days[customer,1 + (day-1)%7] = 1
        #end
    #end
    customer_days = ones(Int,customers, days) #######This removes the time windows
    Instance(customers, vehicles, days, max_hours, customer_work, customer_days, traveltime, wages, c_T, c_W)
end

#---- Generate an instance of the problem (FarmWise data, V in the paper)----#
function getInstanceFromData(schedule, time_travel, schedule_FW; 
                             K=nothing, D=nothing, wages=[[20,0], [30,80], [40,200]], c_T=22.5, c_W=10.35, seed=42, maxHours=14, setup_time=1.16, hours_column=:effective_hours_predicted)
    
    if nrow(schedule)<2
        error("There is no job to perform, please check the input provided for the 'schedule' argument.")
    end
    
    # n is the number of jobs (hence nbr of rows in schedule - 1 to remove the depot)
    n = nrow(schedule) - 1
    # If not specified, K is the maximum number of vehicles used by FW. 
    if K == nothing
        K = length(unique(schedule_FW[!,:robot]))
    end
    
    # If not specified, D is maximum of last day of availability over all fields.
    if D == nothing    
        D = Int(maximum(schedule[!,:end_day]))
    end
            
    # Demand
    workNeeded = (schedule[!,hours_column])[2:end]

    # Client availabilities
    hoursDays = convert(Matrix,schedule[!, [:begin_day,:end_day]])[2:end,:]
    clientDays = zeros(n,D)
    for i in 1:n
        for d in 1:D
            clientDays[i, d] = (d in hoursDays[i,1]:hoursDays[i,2]) ? 1 : 0
        end
    end

    # Travel times adding setup time (depdngin on how the model acres to hours work, setup_time might already be included in effective_hours_predicted)
    timeTravel = Matrix{Float64}(time_travel)
    for i in 1:n+2
        for j in 1:n+2
            if (j!=n+2) & (i!=j)
                timeTravel[i,j] += setup_time
            end
        end
    end

    return Instance(n, K, D, maxHours, workNeeded, clientDays, timeTravel, wages, c_T, c_W)
end