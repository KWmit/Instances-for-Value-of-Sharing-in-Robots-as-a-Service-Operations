using Combinatorics

# ---------- Misceleanous -----------#

# Exclude elements in e from l
function exclude(l, e)
    V = collect(l)
    filter!(x->!(x in e),V)
    return V
end

# ---------- Plan ----------#

# Get total travel time of a plan, starting from the depot, visiting all clients (in the order of p.visits) and back to the depot
function getTravelTime(p, pbm)  #To be deleted by KAI
    clients = getClients(p)
    time = 0
    if length(clients)==0
        return 0
    else 
        time += pbm.timeTravel[1,clients[1]+1]
        for i in 1:length(clients)-1
            time += pbm.timeTravel[clients[i]+1,clients[i+1]+1]
        end
        time += pbm.timeTravel[clients[end]+1,pbm.n+2]
    end
    return time
end

# Return total number of hours worked in the plan
function getWorkTime(p)
    workTime = sum(getHours.(p.visits));
    return workTime
end
    
# Returns optimal assortment of a plan
function TSP(p, pbm) #To be deleted by KAI
    m, opt_plan = Inf, []
    perm = permutations(p.visits)
    for x in perm
        p_new = Plan(p.day,x)
        tt = getTravelTime(p_new, pbm)
        if tt<m
            m = tt
            opt_plan = p_new
        end
    end
    return opt_plan
end

# Return array with day of plan and list of tuples being client and hours of the plan, sorted by increasing client number
# Used in DP in trimPlans function
function orderPlan(p)
    sorted_indexes = sortperm(getClients(p))
    ordered_clients = getClients(p)[sorted_indexes]
    ordered_hours = getHours.(p.visits)[sorted_indexes]
    return [p.day, [(ordered_clients[i], ordered_hours[i]) for i in 1:length(sorted_indexes)]]
end

function orderRoute(p)
    sorted_indexes = sortperm(getClients(p))
    ordered_clients = getClients(p)[sorted_indexes]
    ordered_hours = getHours.(p.visits)[sorted_indexes]
    return [[(ordered_clients[i], ordered_hours[i]) for i in 1:length(sorted_indexes)]]
end

# Return travel costs
function getTravelCost(p, pbm)
    travelTime = getTravelTime(p, pbm)
    return pbm.c_T * travelTime
end

# Return work costs
function getWorkCost(p, pbm)
    workTime = getWorkTime(p)
    return pbm.c_W * workTime
end

# Return operators costs
function getOperatorsCost(p, pbm)
    totalTime = getTravelTime(p, pbm) + getWorkTime(p)
    return maximum([wage[1] * totalTime - wage[2] for wage in pbm.wages])
end
    
# Get cost of a plan
function getCost(p, pbm)
    operatorsCost = getOperatorsCost(p, pbm)
    travelCost = getTravelCost(p, pbm)
    workCost = getWorkCost(p, pbm)
    return operatorsCost + travelCost + workCost
end

# Get reduced cost of a plan
function getRDCost(pbm,dayD,hh,visits,total_travel_time,total_work_load_dis,dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r)
    totalTime = total_work_load_dis + total_travel_time
    totcost = pbm.c_T * total_travel_time + pbm.c_W * total_work_load_dis + maximum([wage[1] * totalTime - wage[2] for wage in pbm.wages])
                
    h=zeros(Float64, pbm.n)
    for visit in visits
        h[visit.client] = visit.hours
    end

    OO = getOOtime(pbm, hh, totalTime, total_travel_time) # to store overtime at each tier for each plan
    rdcost =  totcost - dual_con_veh[dayD]-sum((dual_con_wrk[i]+dual_con_ess) * h[i] for i=1:pbm.n)-sum(dual_con_ovr[ww] * OO[ww] for ww=1:length(pbm.wages))
    
    return totcost, rdcost
end
 
# Get the LB of the reduced cost of a plan (This bound is better)
function getRDCostLB(pbm,dayD,hh, sel_i, total_travel_time, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r, discr_step)
    dis_total = Int(floor((pbm.maxHours-total_travel_time)/discr_step))+length(sel_i)
    max_con_ovr = -1000000
    min_pos_cost = pbm.wages[1][1]
    totalTime = total_travel_time + length(sel_i)*discr_step*1.0
    wwcur = 1
    wwcur1 = 1

    for ww in wwcur1:length(pbm.wages) ## update the max_con_ovr cost
        if totalTime< hh[ww]
            break
        end
        wwcur1 = ww
        max_con_ovr = max(max_con_ovr,dual_con_ovr[ww])
    end

    rdcost = pbm.c_T * total_travel_time + min_pos_cost * total_travel_time - dual_con_veh[dayD]- max_con_ovr * total_travel_time
    rdcost = rdcost + sum((min_pos_cost+pbm.c_W-dual_con_wrk[jj]-dual_con_ess-max_con_ovr)*discr_step*1.0 for jj in sel_i)
    dis_total= dis_total - length(sel_i)

    for jj in sel_i
        add_workload = min(Int(ceil(pbm.workNeeded[jj]/discr_step))-1,dis_total)
        for ww in wwcur1:length(pbm.wages) ## update the max_con_ovr cost
            if (totalTime + add_workload*discr_step)< hh[ww]
                break
            end
            wwcur1 = ww
            max_con_ovr = max(max_con_ovr,dual_con_ovr[ww])
        end

        if (min_pos_cost+pbm.c_W-dual_con_wrk[jj]-dual_con_ess-max_con_ovr)>=0
            break
        end
        rdcost = rdcost + (min_pos_cost+pbm.c_W-dual_con_wrk[jj]-dual_con_ess-max_con_ovr)*discr_step*add_workload
        dis_total = dis_total -add_workload

        totalTime = totalTime + add_workload*discr_step
        for ww in wwcur:length(pbm.wages) ## update the minimum cost
            if totalTime< hh[ww]
                break
            end
            wwcur = ww
            min_pos_cost = pbm.wages[ww][1]
        end

        if dis_total==0 
            break
        end
    end

    return rdcost
end

function getOOtime(pbm, hh, totalTime, travel_time)
    OO=zeros(Float64, length(pbm.wages))
    for ww in 1:length(pbm.wages)
        if totalTime > hh[ww+1]
            OO[ww] = hh[ww+1] - hh[ww]
        elseif totalTime <= hh[ww]
            OO[ww] = 0
        else
            OO[ww] = totalTime - hh[ww]
        end
        Hour_overload = 0 # get rid of the travel time part
        if travel_time > hh[ww+1]
            Hour_overload = hh[ww+1] - hh[ww]
        elseif travel_time <= hh[ww]
            Hour_overload = 0
        else
            Hour_overload = travel_time - hh[ww]
        end
        OO[ww] = OO[ww] - Hour_overload
    end
    return OO
end

# Get linear cost of a plan ###To be deleted tentative for experiments
function getCost_Linear(p, pbm)
    totalTime = getTravelTime(p, pbm) + getWorkTime(p)
    operatorsCost = pbm.wages[1][1] * totalTime - pbm.wages[1][2] 
    travelCost = getTravelCost(p, pbm)
    workCost = getWorkCost(p, pbm)
    return operatorsCost + travelCost + workCost
end

# total time
function tottime(p, pbm)
    totalTime = getTravelTime(p, pbm) + getWorkTime(p)
    return totalTime
end

# Update hours in a plan. Does not modify the plan in place.
function updateHours(p, hours)
    if length(p.visits) != length(hours)
        throw(ArgumentError("Mismatch in length between hours and number of visits in plan to be update"))
    end          
    day = p.day
    visits = p.visits
    new_p = Plan(day, [Visit(visit.client, hours[i]) for (i,visit) in enumerate(visits)])
    return new_p
end
        
# Update hours in a plan. Does not modify the plan in place.
function updateHoursTSP(p, hours)
    if length(p.visits) != length(hours)
        throw(ArgumentError("Mismatch in length between hours and number of visits in plan to be update"))
    end          
    day = p.day
    visits = p.visits
    cost = p.cost
    new_p = PlanTSP(day, cost, [Visit(visit.client, hours[i]) for (i,visit) in enumerate(visits)])
    return new_p
end
        
#---------- Set of plans ----------#

# Return a 2D array (D,len(P)) with a one in (d,index) if P[index].day == d and a 0 otherwise
function getDayInPlan(P, pbm)
    y = zeros(Int, pbm.D, length(P))
    for (i,p) in enumerate(P)
        y[p.day,i] = 1
    end
    return y
end
  
# Return a list of n arrays (one per client). Each array contains the indexes of all plans containing client.
function getPlansClients(P, pbm)
    nbrPlansPerClient = zeros(Int,pbm.n)
    for p in P
        clients = [x for x in getClients(p) if x!=0]
        for client in clients
            nbrPlansPerClient[client]+=1
        end
    end
    clientsPlans = [Array{Int, 1}(undef, nbrPlansPerClient[i]) for i=1:pbm.n]
    indexClientsPlans = zeros(Int,pbm.n).+1
    for (i,p) in enumerate(P)
        clients = [x for x in getClients(p) if x!=0]
        for client in clients
            clientsPlans[client][indexClientsPlans[client]] = i
            indexClientsPlans[client] +=1
        end
    end
    return clientsPlans
end

# Return a list of list, for each plan the list of clients in the plan
function getTabClients(P)
    clientsP = [[] for i=1:length(P)]
    for (i,p) in enumerate(P)
        clientsP[i] = getClients(p)
    end
    return clientsP
end

# Returns vectors matching plan indexes to h indexes (h_index) and plan indexes to dictionary matching client id and h_index within the plan
function getHIndex(P)
    clientsP = getTabClients(P)
    len_h = sum(length.(clientsP))

    j = 1
    h_index = [[] for i=1:length(P)];
    for i in 1:length(P)
        l = length(clientsP[i])
        h_index[i] = j:j+l-1
        j+=l
    end
    h_client_index = [Dict(zip(clientsP[i], h_index[i])) for i=1:length(P)]
    return len_h,h_index,h_client_index
end
        
# Returns array of len_h with for index of h returns the index of the plan
function getIndexJ(P,len_h,h_index)
    index_j = zeros(Int,len_h)
    for i in 1:length(P)
        for j in h_index[i]
            index_j[j] = i
        end
    end
    return index_j    
end
                    
# Return a 2D array. For each client and each plan in P, the nbr of hours spent at the client in the plan.
function getHoursClientInPlan(P, pbm)
    t = zeros(Float64, pbm.n, length(P))
    for (i,p) in enumerate(P)
        for visit in p.visits
            t[visit.client, i] = visit.hours
        end
    end
    return t
end

# Return a dictionnary containing the summary of the three main costs of plans in P_opt
function getCostsSolution(P_opt, pbm)
    travelCosts = sum([getTravelCost(p, pbm) for p in P_opt])
    workCosts = sum([getWorkCost(p, pbm) for p in P_opt])
    operatorsCosts = sum([getOperatorsCost(p, pbm) for p in P_opt])
    costs = Dict(
                "travelCosts" => travelCosts,
                "workCosts" => workCosts,
                "operatorsCosts" => operatorsCosts)
    return costs;
end

# Convert list of plans in P_opt into a list of shifts. A shift is a plan but in a list format [d, k, hour]. 
# Shifts in index list_shifts[i] correspond to machines visiting client i.
function getPLansAsShifts(P_opt, pbm)
    list_shifts = []
    for client in 1:pbm.n
        d = 0
        k = 1
        shifts = []
        for p in P_opt
            if d == p.day
                k+=1
            else
                k = 1
            end
            d = p.day
            if client in getClients(p)
                index = findall(x->x==client, getClients(p))[1]
                hour = getHours.(p.visits)[index]
                append!(shifts,[[d,k,hour]])
            end
        end
        append!(list_shifts,[shifts])
    end
    return list_shifts
end

# Return list with end_day for each client (depot included, with an end day=-1) 
function getEndDayPerClient(P_opt, pbm)
    end_day = zeros(pbm.n+1)
    for client in 1:pbm.n
        last_D = -1
        for p in P_opt
            if (client in getClients(p)) & (p.day>last_D)
                last_D = p.day
            end
        end
        end_day[client+1] = last_D
    end
    last_day = end_day .- schedule[:begin_day]
    return last_day
end
                                                
                                                
# Return a dictionnary containing various KPIs describing the solution described in P_opt
function KPIs(P_opt, pbm)                              
    costs = getCostsSolution(P_opt, pbm)
    avg_time_outside_depot = sum([getTravelTime(p, pbm) + getWorkTime(p) for p in P_opt])/length(P_opt)
    total_time_traveling = sum([getTravelTime(p, pbm) for p in P_opt])
    avg_time_traveling = total_time_traveling/length(P_opt)
    avg_time_worked = sum([getWorkTime(p) for p in P_opt])/length(P_opt)
    avg_nbr_fields_visited = sum([length(p.visits) for p in P_opt])/length(P_opt)
    nbr_vehicles_visiting_i_fields = Dict()
    for p in P_opt
        i = length(p.visits) 
        if i in keys(nbr_vehicles_visiting_i_fields)
            nbr_vehicles_visiting_i_fields[i] += 1
        else
            nbr_vehicles_visiting_i_fields[i] = 1
        end
    end
    KPIs = Dict(
        "nbr_vehicles_visiting_i_fields" => nbr_vehicles_visiting_i_fields,
        "total_time_traveling" => total_time_traveling,
        "avg_time_traveling" => avg_time_traveling,
        "avg_time_worked" => avg_time_worked,
        "avg_nbr_fields_visited" => avg_nbr_fields_visited,
        "nbr_vehicles_visiting_i_fields" => nbr_vehicles_visiting_i_fields,
        "costs" => costs
    )
    return KPIs
end
                                            
                                            