include("VSRP-WD.jl")
include("utils.jl")
using Printf
using IterTools: subsets

##add costs
##Call dominance rules
# Hybrid # Kai
function extendPlanHybridTSP(p, pbm)
    clients = getClients(p)
    A_d = findall(x->x>0,pbm.clientDays[:,p.day])
    extended = []
    for client in exclude(A_d, clients) 
        
        travelTime = p.cost
        if length(clients)==0
            travelTime += pbm.timeTravel[1,client+1]
        else 
            travelTime -= pbm.timeTravel[last(clients)+1,pbm.n+2]
            travelTime += pbm.timeTravel[last(clients)+1,client+1]
        end
        travelTime += pbm.timeTravel[client+1,pbm.n+2]
        
        #Below is to be improved
        #new_p = Plan(p.day,vcat(p.visits,[Visit(client,0)]))
        #travelTime = getTravelTime(new_p, pbm)

        newtsp_p =  PlanTSP(p.day,travelTime,vcat(p.visits,[Visit(client,0)]))#Kai
        
        if travelTime <= pbm.maxHours
            append!(extended, [newtsp_p])
         end
    end
    return extended
end

function extendRoutes(P_opt, R_set, pbm) # extend pure routes to days
    Route_days=[]
    P_opt_new=[]
    for dd in 1:pbm.D
        A_d = findall(x->x>0,pbm.clientDays[:,dd])
        for pp in P_opt

            RR = R_set[pp]
            clients = getClients(RR)
            
            if (issubset(clients,A_d))
                append!(Route_days, [PlanTSP(dd,RR.cost,RR.visits)])
                append!(P_opt_new,pp)
            end
        
        end
    end
    return Route_days,P_opt_new
end

function trimTSPPaths(Plans_next) #Dominance rule in the middle of TSP
    remove_plans = []
    for ii in 1:(length(Plans_next)-1)
        if (ii in remove_plans)
            continue
        end
        dominated = false 
        clients_ii = getClients(Plans_next[ii])
        for jj in (ii+1):length(Plans_next)
            if (jj in remove_plans)
                continue
            end
            clients_jj = getClients(Plans_next[jj])

            if Plans_next[ii].day!= Plans_next[jj].day #Same day or not
                continue
            end
            

            if last(clients_ii)!= last(clients_jj) #Same last client or not
                continue
            end

            if !issetequal(clients_ii, clients_jj) #Same set of served cutomers or not
                continue
            end

            #println(Plans_next[ii]," ", Plans_next[jj])
            if Plans_next[ii].cost >= Plans_next[jj].cost
                dominated = true
                break
            else
                # deleted the dominated
                append!(remove_plans, jj)
            end
        end

        if dominated
            append!(remove_plans, ii)
        end

    end
    remove_plans = sort(remove_plans)
    #println(remove_plans," ", length(remove_plans))
    deleteat!(Plans_next,remove_plans)

    return Plans_next
end

function trimTSPPlans(P) #Dominance rule for final paths
    remove_plans = []
    for ii in 1:(length(P)-1)
        if (ii in remove_plans)
            continue
        end
        dominated = false 
        clients_ii = getClients(P[ii])
        for jj in (ii+1):length(P)
            if (jj in remove_plans)
                continue
            end
            clients_jj = getClients(P[jj])

            if P[ii].day!= P[jj].day #Same day or not
                continue
            end
  
            if !issetequal(clients_ii, clients_jj) #Same set of served cutomers or not
                continue
            end

            #println(P[ii]," ", P[jj])
            if P[ii].cost >= P[jj].cost
                dominated = true
                break
            else
                # deleted the dominated
                append!(remove_plans, jj)
            end
        end

        if dominated
            append!(remove_plans, ii)
        end

    end
    remove_plans = sort(remove_plans)
    #println(remove_plans," ", length(remove_plans))
    deleteat!(P,remove_plans)

    return P
end

# SP # Kai
function extendPlanSPWorkload(P, pbm, discr_step, index_r) # SP
    if discr_step <=0
        throw(ArgumentError("Please us a positive discretization step"))
    end

    extended = []
    indx = []
    for kk in 1:length(P) #We need to impose that each visit should have less than their total workload
        
        p= P[kk]
        dis_total = Int(floor((pbm.maxHours-p.cost)/discr_step)) # Number of discretized time steps that can be added
        clients = getClients(p)
        if length(clients) > dis_total
            continue
        end

        for dis_split in length(clients):dis_total
            Siplit= subsets(1:(dis_split-1), length(clients)-1) # Emuerate all possible combinations

            for ss in Siplit # Emuerate all possible combinations
                append!(ss, dis_split)
                visits = []
                for ii in 1:length(ss)
                    if ii==1
                        visits = append!(visits, [Visit(clients[ii], (ss[ii]-0)*discr_step)]) 
                    else
                        visits = append!(visits, [Visit(clients[ii], (ss[ii]-ss[ii-1])*discr_step)])       
                    end
                end
                append!(extended, [PlanTSP(p.day, p.cost, visits)])
                append!(indx,index_r[kk])
            end
    
        end
       
    end
    return extended, indx
end

# SP # Kai !!!!!!!!!!!!!!!!!!!!!!!!!!Be careful with  length(clients):dis_total and dis_total:dis_total
function extendPlanSPLBWorkload(P, pbm, discr_step, index_r) # SP LB
    if discr_step <=0
        throw(ArgumentError("Please us a positive discretization step"))
    end

    extended = []
    indx = []
    for kk in 1:length(P) #We need to impose that each visit should have less than their total workload
        
        p= P[kk]
        clients = getClients(p)
        dis_total = Int(floor((pbm.maxHours-p.cost)/discr_step))+length(clients) # +length(clients) Number of discretized time steps that can be added=needs the number of cusstomers

        if length(clients) > dis_total
            continue
        end

        for dis_split in length(clients):dis_total #length(clients) #dis_total
            Siplit= subsets(1:(dis_split-1), length(clients)-1) # Emuerate all possible combinations

            for ss in Siplit # Emuerate all possible combinations
                append!(ss, dis_split)
                visits = []
                added = true
                for ii in 1:length(ss)
                    add_ss = 0
                    if ii==1 
                        add_ss = ss[ii]-0
                    else
                        add_ss = ss[ii]-ss[ii-1]
                    end

                    #visits = append!(visits, [Visit(clients[ii], min(add_ss*discr_step,pbm.workNeeded[clients[ii]]))]) 
                    if add_ss > Int(ceil(pbm.workNeeded[clients[ii]]/discr_step)) # if assgined in the plan is greated than needed, jump
                        added=false
                        break
                    elseif add_ss < Int(ceil(pbm.workNeeded[clients[ii]]/discr_step))
                        visits = append!(visits, [Visit(clients[ii], add_ss*discr_step)]) 
                    else 
                        visits = append!(visits, [Visit(clients[ii], pbm.workNeeded[clients[ii]])]) 
                    end

                end
                if added
                    append!(extended, [PlanTSP(p.day, p.cost, visits)])
                    append!(indx,index_r[kk])
                end
            end
    
        end
       
    end
    return extended, indx
end
 
function trimPlansL(P)
    P_new = Vector{PlanTSP}()
    dict_time = Dict()

    for p in P
        ordered_p = orderPlan(p)
        travelTime = p.cost
        if (ordered_p in keys(dict_time)) && (travelTime < dict_time[ordered_p])
            dict_time[ordered_p] = travelTime
        elseif !(ordered_p in keys(dict_time))
            dict_time[ordered_p] = travelTime
        end
    end

    dict_clients_hours = Dict()
    for p in P
        clients_hours_ordered = orderPlan(p)
        timeTravel = p.cost
        if (timeTravel == dict_time[clients_hours_ordered]) && !(haskey(dict_clients_hours, clients_hours_ordered))
            append!(P_new, [p])
            dict_clients_hours[clients_hours_ordered] = 1
        end
    end        
    return P_new
end

function trimRoutesL(P) ## remove repeated route sequences
    Route_s = Vector{RouteP}()
    for p in P
        append!(Route_s, [RouteP(p.cost,p.visits)])
    end

    P= Route_s
    P_new = Vector{RouteP}()
    dict_time = Dict()

    for p in P
        ordered_p = orderRoute(p)
        travelTime = p.cost
        if (ordered_p in keys(dict_time)) && (travelTime < dict_time[ordered_p])
            dict_time[ordered_p] = travelTime
        elseif !(ordered_p in keys(dict_time))
            dict_time[ordered_p] = travelTime
        end
    end

    dict_clients_hours = Dict()
    indx_r=[]
    rr= 0
    for kk in 1:length(P) #We need to impose that each visit should have less than their total workload
        p= P[kk]
        clients_hours_ordered = orderRoute(p)
        timeTravel = p.cost
        if (timeTravel == dict_time[clients_hours_ordered]) && !(haskey(dict_clients_hours, clients_hours_ordered))
            append!(P_new, [p])
            rr= rr+1
            append!(indx_r,rr) # record index of route used
            #dict_clients_hours[clients_hours_ordered] = 1

            dict_clients_hours[clients_hours_ordered] = rr

        else
            append!(indx_r,dict_clients_hours[clients_hours_ordered])
            #dict_clients_hours1= Dict()
            #dict_clients_hours1[clients_hours_ordered] = 1
            #for rr1 in 1:length(P_new)
                #clients_hours_ordered1=orderRoute(P_new[rr1])
                #if(haskey(dict_clients_hours1, clients_hours_ordered1))
                    #append!(indx_r,rr1) # record index of route used
                    #break
                #end
            #end

        end
    end

    if length(indx_r)!=length(P)
        error("Some routes are not labeled with index ")
    end

    return P_new, indx_r
end

function trimPlansPPL(P) ## remove repeated route sequences in pricing problem
    P_new = Vector{PlanTSP_PP}()
    dict_time = Dict()

    for p in P
        ordered_p = orderPlan(p)
        travelTime = p.cost
        if (ordered_p in keys(dict_time)) && (travelTime < dict_time[ordered_p])
            dict_time[ordered_p] = travelTime
        elseif !(ordered_p in keys(dict_time))
            dict_time[ordered_p] = travelTime
        end
    end

    dict_clients_hours = Dict()
    for p in P
        clients_hours_ordered = orderPlan(p)
        timeTravel = p.cost
        if (timeTravel == dict_time[clients_hours_ordered]) && !(haskey(dict_clients_hours, clients_hours_ordered))
            append!(P_new, [p])
            dict_clients_hours[clients_hours_ordered] = 1
        end
    end        
    return P_new
end

#--- Newly add part for designing the algorithm ---#Kai
function getAllPlansDP(pbm; method="Hybrid", max_len_visits=3, discr_step=0)
    Plans = [PlanTSP(d, 0, []) for d in 1:pbm.D] #Kai
    list_plans = [Plans]
    for i in 1:max_len_visits
        Plans_next = []
        for p in list_plans[end]
            append!(Plans_next, extendPlanHybridTSP(p, pbm)) #Kai
        end
        #Plans_next = trimTSPPaths(Plans_next) # remove dominated paths
        append!(list_plans,[Plans_next])
    end
    P = vcat(list_plans...) # Why do we need this?
    P = P[pbm.D+1:end]
    #P = trimTSPPlans(P) 
    P = trimPlansL(P)

    #R_set = P ##Newly added
    indx = []
    index_r= []
    R_set, index_r = trimRoutesL(P)

    #for kk in 1:length(P)
        #println("Route of day ", P[kk], " Route ", R_set[index_r[kk]])
    #end

    if method=="SP"
        P, indx = extendPlanSPWorkload(P, pbm, discr_step, index_r)
    end
    if method=="SP_Ben"
        P, indx = extendPlanSPWorkload(P, pbm, discr_step, index_r)
    end
    if method=="SP_Alg"
        P, indx = extendPlanSPLBWorkload(P, pbm, discr_step, index_r)
    end
    if method=="SP_Alg_CG"
        P, indx = extendPlanSPLBWorkload(P, pbm, discr_step, index_r)
    end
    if method=="SP_LB"
        P, indx = extendPlanSPLBWorkload(P, pbm, discr_step, index_r)
    end
    if method=="SP_LB_CG"
        P, indx = extendPlanSPLBWorkload(P, pbm, discr_step, index_r)
    end
    if method=="SP_LB_CG_with_E"
        P, indx = extendPlanSPLBWorkload(P, pbm, discr_step, index_r)
    end
    println("Plans generated. There are ", length(P), " plans. Method ", method)    
    #for kk in 1:length(P)
        #println("Route of day ", P[kk], " Route ", R_set[indx[kk]])
    #end        
    #R_set=Route_to_tree(R_set)
    return P, R_set, indx 
end
