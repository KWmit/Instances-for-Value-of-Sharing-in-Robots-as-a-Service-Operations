using Gurobi, JuMP, OffsetArrays

include("DP.jl")

function create_model(; Optimizer=Gurobi.Optimizer,  TimeLimit=-1, MIPGap=0.001, LogFile=nothing)
    model = Model(Optimizer);
    if TimeLimit >= 0
        set_optimizer_attribute(model, "TimeLimit", TimeLimit)
    end
    if MIPGap >= 0
        set_optimizer_attribute(model, "MIPGap", MIPGap)
    end
    if LogFile != nothing
        set_optimizer_attribute(model, "LogFile", LogFile)
    else
        set_optimizer_attribute(model, "OutputFlag", 0) # 1 Change to 0 if we do not want to see results
    end
    return model
end;

function termination(model)
    if termination_status(model) == MOI.OPTIMAL
        optimal_objective = objective_value(model)
        gap = relative_gap(model)
        lower_bound = objective_bound(model)
    elseif termination_status(model) == MOI.INFEASIBLE_OR_UNBOUNDED
        optimal_objective = Inf
        gap = Inf
        lower_bound = Inf
    elseif termination_status(model) == MOI.TIME_LIMIT 
        lower_bound = objective_bound(model)
        if has_values(model)
            optimal_objective = objective_value(model)
            gap = relative_gap(model)
        else
            optimal_objective = Inf
            gap = Inf
        end
    else
        println("Unexpected model termination status: ", string(termination_status(model)))
        if has_values(model)
            lower_bound = objective_bound(model)
            optimal_objective = objective_value(model)
            gap = relative_gap(model)
        else
            optimal_objective = Inf
            gap = Inf
            lower_bound = -Inf
        end
    end
    return optimal_objective, gap, lower_bound
end

function getOptimalPlans(pbm, model, method; P=[], h_index=[], A=[])
    if !(method in ["SP", "Classic", "Hybrid"])
        throw(ArgumentError("Please use one of the following methods: 'Hybrid', 'SP' or 'Classic'"))
    end
        
    P_opt = Vector{Plan}()
    if has_values(model)
        x_opt = value.(model[:x])

        if method == "SP"
            opt_indexes = findall(x->x>0.5, x_opt)
            for opt_index in opt_indexes
                #p = P[opt_index]
                p = Plan(P[opt_index].day,P[opt_index].visits)
                n_vehicles = Int(round(x_opt[opt_index]))
                append!(P_opt, repeat([p], outer = n_vehicles)) 
            end

        elseif method == "Hybrid"
            opt_indexes = findall(x->x>0.5, x_opt)
            h_opt = value.(model[:h_var])
            for opt_index in opt_indexes
                p = P[opt_index]
                n_vehicles = Int(round(x_opt[opt_index]))
                hours = h_opt[h_index[opt_index]] / n_vehicles
                new_p = updateHours(p, hours)
                append!(P_opt, repeat([new_p], outer = n_vehicles))
            end

        elseif method == "Classic"
            h_opt = value.(model[:h])
            for d in 1:pbm.D
                for k in 1:pbm.K
                    visits = []
                    for (i,j) in A
                        if x_opt[(i,j),k,d]>0.5 && j!= pbm.n + 1
                            append!(visits, [Visit(j, h_opt[j,k,d])])
                        end
                    end
                    if length(visits)>0
                        append!(P_opt, [Plan(d, visits)])
                    end
                end
            end
        end
    end
    return P_opt
end

function getOptimalRoutes(model, indx; Opt_route=[]) # extract the set of routes index that are positive
    if has_values(model)
        x_opt = value.(model[:x])
        opt_indexes = findall(x->x>0.01, x_opt)
        for opt_index in opt_indexes
            append!(Opt_route,  indx[opt_index]) 
        end
    end
    return Opt_route
end

function getAddedPlans(model, indx; P=[], h_index=[])
    P_opt = Vector{PlanTSP}()
    indx_r = []
    if has_values(model)
        x_opt = value.(model[:x])
        opt_indexes = findall(x->x>0.5, x_opt)
            h_opt = value.(model[:h_var])
            for opt_index in opt_indexes
                p = P[opt_index]
                n_vehicles = Int(round(x_opt[opt_index]))
                hours = h_opt[h_index[opt_index]] / n_vehicles
                new_p = updateHoursTSP(p, hours)
                append!(P_opt, [new_p]) ## do not repeat
                append!(indx_r, indx[opt_index]) 
            end
    end
    return P_opt, indx_r
end
 
# Creates useful sets for the Classic formulation
function getIndexesClassic(pbm)
    A = [(i,j) for i in 0:pbm.n for j in 1:pbm.n+1 if j!=i]
    I = OffsetVector([[j for j in 1:pbm.n+1 if j!=i] for i in 0:pbm.n],0:pbm.n)
    J = [[i for i in 0:pbm.n if j!=i] for j in 1:pbm.n+1];
    E = [(i,j) for i in 1:pbm.n for j in 1:pbm.n if j!=i]
    L = [(i,j,l) for i in 1:pbm.n for j in 1:pbm.n for l in 1:pbm.n if (j!=i) & (i!=l) & (j!=l)]
    return A,I,J,E,L
end

function solveClassic(pbm, Optimizer, maxTime, max_len_visits, LogFile)
    # Only works with max_len_visits <= 3
    A,I,J,E,L = getIndexesClassic(pbm)
    model = create_model(Optimizer=Optimizer, TimeLimit=maxTime, LogFile=LogFile)
    
    @variable(model, x[A, 1:pbm.K, 1:pbm.D], Bin)
    @variable(model, h[1:pbm.n, 1:pbm.K, 1:pbm.D] >= 0)
    @variable(model, ω[1:pbm.K, 1:pbm.D] >= 0)
    @variable(model, y[0:pbm.n+1, 1:pbm.K, 1:pbm.D], Bin)

    # ranking customers in order
    @variable(model, v[0:pbm.n+1, 1:pbm.K, 1:pbm.D] >= 0, Int)
    @constraint(model, [(i,j)=A, k=1:pbm.K, d=1:pbm.D], v[i,k,d]-v[j,k,d]+1 <= (pbm.n+1)*(1-x[(i,j),k,d]))
    @constraint(model, [k=1:pbm.K, d=1:pbm.D], v[0,k,d]  == 0)

    @constraint(model,[k=1:pbm.K, d=1:pbm.D], sum(x[(0,j),k,d] for j in 1:pbm.n+1) == 1)
    @constraint(model,[k=1:pbm.K, d=1:pbm.D], sum(x[(i,pbm.n+1),k,d] for i=0:pbm.n) == 1)
    @constraint(model,[l=1:pbm.n, k=1:pbm.K, d=1:pbm.D], sum(x[(i,l),k,d] for i in J[l]) == sum(x[(l,j),k,d] for j in I[l]))
    
    # New constraints
    #@constraint(model, [k=1:pbm.K, d=1:pbm.D], sum(y[i,k,d] for i in 1:pbm.n) <= max_len_visits)
    #if max_len_visits > 1
        #@constraint(model, [(i,j)=E,k=1:pbm.K,d=1:pbm.D], x[(i,j),k,d] + x[(j,i),k,d] <= 1) # Removing 2-cycles
    #end
    #if max_len_visits > 2
        #@constraint(model, [(i,j,l)=L, k=1:pbm.K, d=1:pbm.D], x[(i,j),k,d] + x[(j,i),k,d] + 
                                                              #x[(i,l),k,d] + x[(l,i),k,d] +
                                                              #x[(j,l),k,d] + x[(l,j),k,d] <= 1) # Removing 3-cycles
    #end
    
    @constraint(model, [(i,j)=A, k=1:pbm.K, d=1:pbm.D], x[(i,j),k,d] <= y[i,k,d])
    @constraint(model, [(i,j)=A, k=1:pbm.K, d=1:pbm.D], x[(i,j),k,d] <= y[j,k,d])
    @constraint(model, [j=1:pbm.n, k=1:pbm.K, d=1:pbm.D], y[j,k,d] <= sum(x[(i,j),k,d] for i in J[j]))
    
    @constraint(model, [i=1:pbm.n, k=1:pbm.K, d=1:pbm.D], h[i,k,d] <= pbm.maxHours * y[i,k,d])
    @constraint(model, [i=1:pbm.n], sum(sum(h[i,k,d] for d in 1:pbm.D) for k in 1:pbm.K) >= pbm.workNeeded[i])
    @constraint(model, [i=1:pbm.n, k=1:pbm.K, d=1:pbm.D], y[i,k,d] <= pbm.clientDays[i,d])
    @constraint(model, [k=1:pbm.K, d=1:pbm.D], sum(x[(i,j),k,d] * pbm.timeTravel[i+1,j+1] for (i,j) in A) + sum(h[i,k,d] for i in 1:pbm.n) <= pbm.maxHours)
    
    for wage in pbm.wages
        @constraint(model, [k=1:pbm.K, d=1:pbm.D], ω[k,d] >= wage[1] * (sum(x[(i,j),k,d]*pbm.timeTravel[i+1,j+1] for (i,j) in A) + sum(h[i,k,d] for i in 1:pbm.n)) - wage[2])
    end
    
    @objective(model, Min, sum(sum(ω[k,d] for k in 1:pbm.K) for d in 1:pbm.D) +
                           sum(sum(sum(x[(i,j),k,d] * pbm.timeTravel[i+1,j+1] for (i,j) in A) * pbm.c_T +
                                   sum(h[i,k,d] for i in 1:pbm.n) * pbm.c_W
                                   for d in 1:pbm.D)
                                   for k in 1:pbm.K));
    @suppress optimize!(model)

    optimal_objective, gap, lower_bound = termination(model) 
    P_opt = getOptimalPlans(pbm, model, "Classic", A=A)
            
    return model, optimal_objective, gap, lower_bound, P_opt;    
end

function solveSP(pbm, P, Optimizer, maxTime, LogFile)
    c = [getCost(p, pbm) for p in P]
    h = getHoursClientInPlan(P, pbm);
    y = getDayInPlan(P, pbm);
    
    model = create_model(Optimizer=Optimizer, TimeLimit=maxTime, LogFile=LogFile)
    @variable(model, x[1:length(P)], Int);
    
    @constraint(model, [index=1:length(P)], x[index]>=0)
    @constraint(model, [d=1:pbm.D], sum(y[d,index] * x[index] for index in 1:length(P)) <= pbm.K);
    @constraint(model, [i=1:pbm.n], sum(x[index] * h[i,index] for index in 1:length(P)) >= pbm.workNeeded[i]);
    
    @objective(model, Min, sum(c[index]*x[index] for index in 1:length(P)));
    
    @suppress optimize!(model);

    optimal_objective, gap, lower_bound = termination(model)
    P_opt = getOptimalPlans(pbm, model, "SP", P=P)
    return model, optimal_objective, gap, lower_bound, P_opt;
end

function solveHybrid(pbm, P, Optimizer, maxTime, LogFile, front_loaded, λ, μ)
    clientsPlans = getPlansClients(P, pbm) # For each customer, identify the set of plans that involves the customer
    totalRoundTrip = [p.cost for p in P] # get the travel cost of plan
 
    y =  getDayInPlan(P, pbm); ## for each day, show whether a plan can be used to it
    len_h,h_index,h_client_index = getHIndex(P) ##len_h: Total length of h variables; h_index: for each plan, the set of cusotmers visisted. h_client_index: index of h variable given customer i and plan p
    index_j = getIndexJ(P,len_h,h_index) ## Get the associated plan for the h variable
    
    # Only for front_loaded=true
    day = [p.day - 1 for p in P]
    
    model = create_model(Optimizer=Optimizer, TimeLimit=maxTime, MIPGap=0.0000001, LogFile=LogFile) #0.001
    @variable(model, x[i=1:length(P)], Int); 
    @variable(model, t[i=1:length(P)]>=0);
    @variable(model, h_var[j=1:len_h]>= 0)

    @constraint(model, [index=1:length(P)], x[index]>=0)
    @constraint(model, [d=1:pbm.D],sum(y[d,index] * x[index] for index in 1:length(P)) <= pbm.K); #y[d,index] \in [0,1] where path in the day D or not
 
    @constraint(model,[index=1:length(P)], sum(h_var[j] for j in h_index[index]) <= x[index] * (pbm.maxHours - totalRoundTrip[index]));
    @constraint(model,[j=1:len_h], h_var[j] <= (pbm.maxHours - totalRoundTrip[index_j[j]])*x[index_j[j]]);
    
    @constraint(model,[client=1:pbm.n], sum(h_var[h_client_index[i_p][client]] for i_p in clientsPlans[client]) >= pbm.workNeeded[client]);
    
    for wage in pbm.wages
        @constraint(model, [index=1:length(P)], t[index]>= wage[1] * (totalRoundTrip[index]*x[index]+sum(h_var[j] for j in h_index[index])) - wage[2] * x[index])
    end


#=     for index in 1:length(P) #Workload-sharing solution: every job CAN be visited by several machines but every machine visits ≤1 job
        if (length(getClients(P[index]))>1)
            @constraint(model, x[index]==0)
        end
    end

    for client in 1:pbm.n #Machine-sharing solution: every machine CAN visit several jobs but every job is visited by ≤1 machine
        job_in_plan =zeros(length(P))
        for index in 1:length(P)
            if client in getClients(P[index])
                job_in_plan[index]=1
            end
        end
        @constraint(model, sum(job_in_plan[index]*x[index] for index in 1:length(P))<=1)
    end  =#

#=     for client in 1:pbm.n #Joint-sharing: If a job is visited by several machines, then these machines visit only that job
        job_in_plan =zeros(length(P))
        job_only_plan =zeros(length(P))
        for index in 1:length(P)
            if (client in getClients(P[index])) & (length(getClients(P[index]))>1)
                job_in_plan[index]=1
            end
            if (client in getClients(P[index])) & (length(getClients(P[index]))==1)
                job_only_plan[index]=1
            end
        end
        @constraint(model, sum(job_in_plan[index]*x[index] for index in 1:length(P))<=1)
        @constraint(model, sum(job_only_plan[index]*x[index] for index in 1:length(P))<=pbm.K*(1-sum(job_in_plan[index]*x[index] for index in 1:length(P))))
    end   =#

    
    if front_loaded # add opportunity cost in the obj

        @objective(model, Min,sum(t[index]
                              + totalRoundTrip[index]*x[index]*pbm.c_T
                              + sum(h_var[j] for j in h_index[index])*pbm.c_W
                              - λ*sum(h_var[j] for j in h_index[index])*exp(-μ*day[index])  
                              for index in 1:length(P)));
    else
        @objective(model, Min,sum(t[index]
                              + totalRoundTrip[index]*x[index]*pbm.c_T
                              + sum(h_var[j] for j in h_index[index])*pbm.c_W
                              for index in 1:length(P)));   
        #@objective(model, Min,sum(t[index] # opp cost
                                #+ totalRoundTrip[index]*x[index]*pbm.c_T
                                #+ sum(h_var[j] for j in h_index[index])*pbm.c_W
                                #for index in 1:length(P))+2*sum(
                                    #totalRoundTrip[index]*x[index]
                                    #+ sum(h_var[j] for j in h_index[index])
                                    #for index in 1:length(P)));
    end
    @suppress optimize!(model);
    
    optimal_objective, gap, lower_bound = termination(model)
        
    if (front_loaded) & (optimal_objective>0) & (optimal_objective!=Inf)  
        h_opt = value.(model[:h_var])
        optimal_objective += λ * sum(sum(h_opt[j] 
                                        for j in h_index[index])*exp(-μ*day[index]) 
                                        for index in 1:length(P))
    end
    P_opt = getOptimalPlans(pbm, model, "Hybrid", P=P, h_index=h_index)
    
    return model, optimal_objective, gap, lower_bound, P_opt;
end

function modelSPAlg(pbm, P, Optimizer, LogFile, method, discr_step=0) 
    c = [getCost(p, pbm) for p in P]
    T_p =  [tottime(p, pbm) for p in P]

    hh=vcat([0], [(pbm.wages[wa+1][2]-pbm.wages[wa][2])/(pbm.wages[wa+1][1]-pbm.wages[wa][1]) for wa in 1:(length(pbm.wages)-1)],[pbm.maxHours*2]) # get breakpoints of functions
    OO=zeros(Float64, length(P),length(pbm.wages)) # to store overtime at each tier for each plan

    for pp in eachindex(P) #claculate the budget of each plan at each tier
        p = P[pp] 
        travel_time = p.cost
        totalTime = travel_time + getWorkTime(p)
        for ww in 1:length(pbm.wages)

            if totalTime > hh[ww+1]
                OO[pp,ww] = hh[ww+1] - hh[ww]
            elseif totalTime <= hh[ww]
                OO[pp,ww] = 0
            else
                OO[pp,ww] = totalTime - hh[ww]
            end
            Hour_overload = 0 # get rid of the travel time part
            if travel_time > hh[ww+1]
                Hour_overload = hh[ww+1] - hh[ww]
            elseif travel_time <= hh[ww]
                Hour_overload = 0
            else
                Hour_overload = travel_time - hh[ww]
            end
            OO[pp,ww] = OO[pp,ww] - Hour_overload
        end
    end
 
    h = getHoursClientInPlan(P, pbm);
    y = getDayInPlan(P, pbm);
    
    model = create_model(Optimizer=Optimizer, MIPGap=0.001, LogFile=LogFile) ##0.005gap
    @variable(model, x[1:length(P)], Int);
    @variable(model, EE>=0);
    @variable(model, Or[1:length(pbm.wages)]>=0);
    @variable(model, RR>=0);

    @constraint(model, [index=1:length(P)], x[index]>=0)
    @constraint(model, [d=1:pbm.D], sum(y[d,index] * x[index] for index in 1:length(P)) <= pbm.K);
    @constraint(model, [i=1:pbm.n], sum(x[index] * h[i,index] for index in 1:length(P)) >= pbm.workNeeded[i]);

    @constraint(model, sum(sum(x[index] * h[i,index] for index in 1:length(P)) - pbm.workNeeded[i] for i in 1:pbm.n)==EE);
    
    @constraint(model,[ww=1:length(pbm.wages)] ,sum(OO[index,ww] * x[index] for index in 1:length(P))==Or[ww]);
    @constraint(model, [ww=1:length(pbm.wages)], pbm.wages[ww][1]*EE+sum(Or[wa] * (pbm.wages[wa][1]-pbm.wages[ww][1]) for wa in (ww+1):length(pbm.wages))>=RR);

    ##Feasibility cuts
    cr=ones(Int, length(P)) # a vector of element one if the route is not in the set
    @constraint(model, cut_r ,sum(cr[index] * x[index] for index in 1:length(P)) >= 1); #stepwise for search
     
    @objective(model, Min, sum(c[index]*x[index] for index in 1:length(P))-RR-pbm.c_W*EE);
    return model, cut_r, x;
end

function optSPAlg(model, cut_r, x, indx,  P_opt, x_solution, time_limit)
    if time_limit > 0
        set_optimizer_attribute(model, "TimeLimit", time_limit)
    end
     
    for index in eachindex(x)
        if indx[index] in P_opt
            set_normalized_coefficient(cut_r, x[index], 0)
        end
    end
     
    # A warmup
    xx = all_variables(model)
    if P_opt!=[]
        set_start_value.(xx, x_solution)
    end

     
    @suppress optimize!(model);

    optimal_objective, gap, lower_bound = termination(model)
    #P_opt = getOptimalPlans(pbm, model, "SP", P=P)

    Opt_route = getOptimalRoutes(model, indx) # get the set of routes positive
    P_opt = unique(Opt_route)

    
    # A warmup
    if Opt_route!=[]
        x_solution = value.(xx)
    end
    #r_opt =[]
    #xr_opt = value.(model[:xr])
    #for iir in 1:length(xr_opt)
        #if xr_opt[iir]>0.1
            #append!(r_opt,  iir) 
        #end
    #end
    #println("Verfied: ",r_opt)

    return model, optimal_objective, gap, lower_bound, P_opt, x_solution;
end

function solveHybridAlg(pbm, P, Optimizer, maxTime, LogFile, front_loaded, λ, μ, indx)
    clientsPlans = getPlansClients(P, pbm) # For each customer, identify the set of plans that involves the customer
    totalRoundTrip = [p.cost for p in P] # get the travel cost of plan
  
    y =  getDayInPlan(P, pbm); ## for each day, show whether a plan can be used to it
    len_h,h_index,h_client_index = getHIndex(P) ##len_h: Total length of h variables; h_index: for each plan, the set of cusotmers visisted. h_client_index: index of h variable given customer i and plan p
    index_j = getIndexJ(P,len_h,h_index) ## Get the associated plan for the h variable
    
    # Only for front_loaded=true
    day = [p.day - 1 for p in P]
    
    model = create_model(Optimizer=Optimizer, TimeLimit=maxTime, MIPGap=0.001, LogFile=LogFile)
    @variable(model, x[i=1:length(P)], Int); 
    @variable(model, t[i=1:length(P)]>=0);
    @variable(model, h_var[j=1:len_h]>= 0)

    @constraint(model, [index=1:length(P)], x[index]>=0)
    @constraint(model, [d=1:pbm.D],sum(y[d,index] * x[index] for index in 1:length(P)) <= pbm.K); #y[d,index] \in [0,1] where path in the day D or not
    
    @constraint(model,[index=1:length(P)], sum(h_var[j] for j in h_index[index]) <= x[index] * (pbm.maxHours - totalRoundTrip[index]));
    @constraint(model,[j=1:len_h], h_var[j] <= (pbm.maxHours - totalRoundTrip[index_j[j]])*x[index_j[j]]);
    
    @constraint(model,[client=1:pbm.n], sum(h_var[h_client_index[i_p][client]] for i_p in clientsPlans[client]) >= pbm.workNeeded[client]);
    
    for wage in pbm.wages
        @constraint(model, [index=1:length(P)], t[index]>= wage[1] * (totalRoundTrip[index]*x[index]+sum(h_var[j] for j in h_index[index])) - wage[2] * x[index])
    end
    
    if front_loaded # add opportunity cost in the obj

        @objective(model, Min,sum(t[index]
                              + totalRoundTrip[index]*x[index]*pbm.c_T
                              + sum(h_var[j] for j in h_index[index])*pbm.c_W
                              - λ*sum(h_var[j] for j in h_index[index])*exp(-μ*day[index])  
                              for index in 1:length(P)));
    else
        @objective(model, Min,sum(t[index]
                              + totalRoundTrip[index]*x[index]*pbm.c_T
                              + sum(h_var[j] for j in h_index[index])*pbm.c_W
                              for index in 1:length(P)));   
        #@objective(model, Min,sum(t[index] # opp cost
                                #+ totalRoundTrip[index]*x[index]*pbm.c_T
                                #+ sum(h_var[j] for j in h_index[index])*pbm.c_W
                                #for index in 1:length(P))+2*sum(
                                    #totalRoundTrip[index]*x[index]
                                    #+ sum(h_var[j] for j in h_index[index])
                                    #for index in 1:length(P)));
    end
    @suppress optimize!(model);
    
    optimal_objective, gap, lower_bound = termination(model)
        
    if (front_loaded) & (optimal_objective>0) & (optimal_objective!=Inf)  
        h_opt = value.(model[:h_var])
        optimal_objective += λ * sum(sum(h_opt[j] 
                                        for j in h_index[index])*exp(-μ*day[index]) 
                                        for index in 1:length(P))
    end
  
    #P_opt, indx_r = getAddedPlans(model, indx, P=P, h_index=h_index) ## need this if we need column generation
    #return model, optimal_objective, gap, P_opt, indx_r;

    P_opt = getOptimalPlans(pbm, model, "Hybrid", P=P, h_index=h_index)
    return model, optimal_objective, gap, lower_bound, P_opt;
end

function solveHybridSP(pbm, P, Optimizer, maxTime, LogFile, front_loaded, λ, μ)
    clientsPlans = getPlansClients(P, pbm) # For each customer, identify the set of plans that involves the customer
    totalRoundTrip = [getTravelTime(p, pbm) for p in P]

    y =  getDayInPlan(P, pbm); ## for each day, show whether a plan can be used to it
    len_h,h_index,h_client_index = getHIndex(P) ##len_h: Total length of h variables; h_index: for each plan, the set of cusotmers visisted. h_client_index: index of h variable given customer i and plan p
    index_j = getIndexJ(P,len_h,h_index) ## Get the associated plan for the h variable
    
    # Only for front_loaded=true
    day = [p.day - 1 for p in P]
    
    model = create_model(Optimizer=Optimizer, TimeLimit=maxTime, LogFile=LogFile)
    @variable(model, x[i=1:length(P)], Int); 
    @variable(model, t[i=1:length(P)]>=0);
    @variable(model, h_var[j=1:len_h]>= 0)

    @constraint(model, [index=1:length(P)], x[index]>=0)
    @constraint(model, [d=1:pbm.D],sum(y[d,index] * x[index] for index in 1:length(P)) <= pbm.K); #y[d,index] \in [0,1] where path in the day D or not
    
    @constraint(model,[index=1:length(P)], sum(h_var[j] for j in h_index[index]) <= x[index] * (pbm.maxHours - totalRoundTrip[index]));
    @constraint(model,[j=1:len_h], h_var[j] <= (pbm.maxHours - totalRoundTrip[index_j[j]])*x[index_j[j]]);
    
    @constraint(model,[client=1:pbm.n], sum(h_var[h_client_index[i_p][client]] for i_p in clientsPlans[client]) >= pbm.workNeeded[client]);
    
    for wage in pbm.wages
        @constraint(model, [index=1:length(P)], t[index]>= wage[1] * (totalRoundTrip[index]*x[index]+sum(h_var[j] for j in h_index[index])) - wage[2] * x[index])
    end
    
    if front_loaded # add opportunity cost in the obj

        @objective(model, Min,sum(t[index]
                              + totalRoundTrip[index]*x[index]*pbm.c_T
                              + sum(h_var[j] for j in h_index[index])*pbm.c_W
                              - λ*sum(h_var[j] for j in h_index[index])*exp(-μ*day[index])  
                              for index in 1:length(P)));
    else
        @objective(model, Min,sum(t[index]
                              + totalRoundTrip[index]*x[index]*pbm.c_T
                              + sum(h_var[j] for j in h_index[index])*pbm.c_W
                              for index in 1:length(P)));   
        #@objective(model, Min,sum(t[index] # opp cost
                                #+ totalRoundTrip[index]*x[index]*pbm.c_T
                                #+ sum(h_var[j] for j in h_index[index])*pbm.c_W
                                #for index in 1:length(P))+2*sum(
                                    #totalRoundTrip[index]*x[index]
                                    #+ sum(h_var[j] for j in h_index[index])
                                    #for index in 1:length(P)));
    end
    @suppress optimize!(model);
    
    optimal_objective, gap, lower_bound = termination(model)
        
    if (front_loaded) & (optimal_objective>0) & (optimal_objective!=Inf)  
        h_opt = value.(model[:h_var])
        optimal_objective += λ * sum(sum(h_opt[j] 
                                        for j in h_index[index])*exp(-μ*day[index]) 
                                        for index in 1:length(P))
    end
    P_opt = getOptimalPlans(pbm, model, "Hybrid", P=P, h_index=h_index)
    
    return model, optimal_objective, gap, lower_bound, P_opt;
end

function warmup_routes(indx,  P) ##warup routes
    Opt_route=[]
    for pp in 1:length(P) #claculate the budget of each plan at each tier
        p = P[pp] 
        clients = getClients(p)
        if length(clients) > 1
            continue
        end
        append!(Opt_route,  indx[pp]) 
    end
 
    P_opt = unique(Opt_route)
    
    return P_opt;
end

#### CG Procedure to solve SP
function RMP_modelSPAlg(pbm, P, Optimizer, LogFile, method, discr_step=0) 
    c = [getCost(p, pbm) for p in P]
    T_p =  [tottime(p, pbm) for p in P]

    hh=vcat([0], [(pbm.wages[wa+1][2]-pbm.wages[wa][2])/(pbm.wages[wa+1][1]-pbm.wages[wa][1]) for wa in 1:(length(pbm.wages)-1)],[pbm.maxHours*2]) # get breakpoints of functions
    OO=zeros(Float64, length(P),length(pbm.wages)) # to store overtime at each tier for each plan

    for pp in eachindex(P) #claculate the budget of each plan at each tier
        p = P[pp] 
        travel_time = p.cost
        totalTime = travel_time + getWorkTime(p)
        for ww in 1:length(pbm.wages)

            if totalTime > hh[ww+1]
                OO[pp,ww] = hh[ww+1] - hh[ww]
            elseif totalTime <= hh[ww]
                OO[pp,ww] = 0
            else
                OO[pp,ww] = totalTime - hh[ww]
            end
            Hour_overload = 0 # get rid of the travel time part
            if travel_time > hh[ww+1]
                Hour_overload = hh[ww+1] - hh[ww]
            elseif travel_time <= hh[ww]
                Hour_overload = 0
            else
                Hour_overload = travel_time - hh[ww]
            end
            OO[pp,ww] = OO[pp,ww] - Hour_overload
        end
    end
 
    h = getHoursClientInPlan(P, pbm);
    y = getDayInPlan(P, pbm);
    
    model = create_model(Optimizer=Optimizer, MIPGap=0.001, LogFile=LogFile) ##0.005gap
    @variable(model, x[1:length(P)]>=0); #initial columns, set to continuous variables

    @variable(model, EE>=0);
    @variable(model, Or[1:length(pbm.wages)]>=0);
    @variable(model, RR>=0);

    @constraint(model, con_veh[d=1:pbm.D], sum(y[d,index] * x[index] for index in 1:length(P)) <= pbm.K);
    @constraint(model, con_wrk[i=1:pbm.n], sum(x[index] * h[i,index] for index in 1:length(P)) >= pbm.workNeeded[i]);

    @constraint(model, con_ess, sum(sum(x[index] * h[i,index] for index in 1:length(P)) - pbm.workNeeded[i] for i in 1:pbm.n)-EE==0);
    
    @constraint(model, con_ovr[ww=1:length(pbm.wages)], sum(OO[index,ww] * x[index] for index in 1:length(P))-Or[ww]==0);
    @constraint(model, con_dut[ww=1:length(pbm.wages)], pbm.wages[ww][1]*EE+sum(Or[wa] * (pbm.wages[wa][1]-pbm.wages[ww][1]) for wa in (ww+1):length(pbm.wages))-RR>=0);

    ##Feasibility cuts
    cr=ones(Int, length(P)) # a vector of element one if the route is not in the set
    @constraint(model, cut_r ,sum(cr[index] * x[index] for index in 1:length(P)) >= 1); #stepwise for search
     
    @objective(model, Min, sum(c[index]*x[index] for index in 1:length(P))-RR-pbm.c_W*EE);

    ##Create a dummy column###
    push!(x, @variable(model, lower_bound = 0))
    set_objective_coefficient(model, x[end], 99999999)
    for d in 1:pbm.D # constraints  con_veh
        set_normalized_coefficient(con_veh[d], x[end], pbm.K)
    end
    for i in 1:pbm.n # constraints  con_wrk
        set_normalized_coefficient(con_wrk[i], x[end], pbm.workNeeded[i])
    end
    # constraints con_ess
    set_normalized_coefficient(con_ess, x[end], sum(pbm.workNeeded[:]))
    # constraints  con_cut
    set_normalized_coefficient(cut_r, x[end], 100)

    return model, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x, c, y, h, OO;
end

function RMP_optSPAlg(model, pbm, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x_solution)
  
    @suppress optimize!(model);

    #optimal_objective = termination(model)
    if termination_status(model) == MOI.OPTIMAL
        optimal_objective=objective_value(model)
        dual_con_veh = [dual(con_veh[d]) for d=1:pbm.D]
        dual_con_wrk = [dual(con_wrk[i]) for i=1:pbm.n]
        dual_con_ess = dual(con_ess) 
        dual_con_ovr = [dual(con_ovr[ww]) for ww=1:length(pbm.wages)]
        dual_con_dut = [dual(con_dut[ww]) for ww=1:length(pbm.wages)]
        dual_cut_r = dual(cut_r)
    else
        println("RMP infeasible solutions")
        dual_con_veh = [0 for d=1:pbm.D]
        dual_con_wrk = [0 for i=1:pbm.n]
        dual_con_ess = 0 
        dual_con_ovr = [0 for ww=1:length(pbm.wages)]
        dual_con_dut = [0 for ww=1:length(pbm.wages)]
        dual_cut_r = 0
    end
 
    return model, optimal_objective, x_solution, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r;
end

function RMP_addcolumnsPP(model, pbm, indx, P_opt, R_set, x, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r,discr_step) 
    #Re-calculate the costs for all parameters
    Plans = [PlanTSP_PP(d, 0, [], 0, 0, 0, 0, 0) for d in 1:pbm.D] #Kai
    non_dominated_plans = []
    hh=vcat([0], [(pbm.wages[wa+1][2]-pbm.wages[wa][2])/(pbm.wages[wa+1][1]-pbm.wages[wa][1]) for wa in 1:(length(pbm.wages)-1)],[pbm.maxHours*2]) # get breakpoints of functions
    most_neg = 0 ## most negative reduced cost.
 
    order_c = reverse(sortperm(dual_con_wrk))
    # no need to use dominance rule?
    for d in 1:pbm.D
        A_d = findall(x->x>0,pbm.clientDays[:,d])
 
        for indexrr in eachindex(R_set)  ### Change this to tree?
            dual_added=0
            yes_set = 0
            if !(indexrr in P_opt)
                dual_added=-dual_cut_r
                yes_set =1
            end
            
            rr= R_set[indexrr]
            clients = getClients(rr)
            if !issubset(clients, A_d)
                continue
            end
            dis_total = Int(floor((pbm.maxHours-rr.cost)/discr_step))+length(clients) # +length(clients) Number of discretized time steps that can be added=needs the number of cusstomers
    
            if length(clients) > dis_total
                continue
            end     

            sel_i = intersect(order_c, clients) # rank customers to add.

            ## Compute the LB of a route and remove it if less than incumbent
            rdcostLB = getRDCostLB(pbm,d, hh, sel_i, rr.cost, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r, discr_step)
            if (rdcostLB>=most_neg)
                continue
            end
 
            # The first plan
            workload_n = ones(pbm.n) # workload assgined to customers
            visitfs = []
            for cc in clients
                visitfs = append!(visitfs, [Visit(cc, workload_n[cc]*discr_step)]) 
            end
            total_travel_time = rr.cost
            total_work_load_dis = sum(getHours.(visitfs))
            totcost, rdcost = getRDCost(pbm, d,hh,visitfs,total_travel_time,total_work_load_dis,dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r)
            newtsp_pp = PlanTSP_PP(d, total_travel_time, visitfs, total_work_load_dis, yes_set, totcost, rdcost+dual_added, indexrr)
            append!(non_dominated_plans, [newtsp_pp])

            # ranking customers by w_j from highest to lowest then assign by order.
            dis_split = length(clients) + 1
            cus_ind = 1
            cur_cus = sel_i[cus_ind]
            while dis_split<= dis_total                
                if workload_n[cur_cus]*discr_step > pbm.workNeeded[cur_cus]
                    cus_ind = cus_ind + 1
                end
              
                if cus_ind>length(sel_i)
                    break
                end
                cur_cus = sel_i[cus_ind]

                workload_n[cur_cus] = workload_n[cur_cus] + 1.0
                visitfs = []
                for cc in clients
                    visitfs = append!(visitfs, [Visit(cc, min(workload_n[cc]*discr_step,pbm.workNeeded[cc]))]) 
                end
                total_travel_time = rr.cost
                total_work_load_dis = sum(getHours.(visitfs))
                totcost, rdcost = getRDCost(pbm, d,hh,visitfs,total_travel_time,total_work_load_dis,dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r)
                newtsp_pp = PlanTSP_PP(d, total_travel_time, visitfs, total_work_load_dis, yes_set, totcost, rdcost+dual_added, indexrr)
                append!(non_dominated_plans, [newtsp_pp])
                if (rdcost < most_neg)
                    most_neg=rdcost
                end
                dis_split = dis_split+1
            end

            ##!!!!!!!!!! Add part dealing with min(workload_n[cc]*discr_step,pbm.workNeeded[cc])) issue!!!!!!!!!!!!!!!
            if length(sel_i)>1
                for sw in 1:(length(sel_i)-1)
                    dis_split = dis_total - length(clients)
                    workload_n = ones(pbm.n) 
                    cus_ind = 1
                    cur_cus = sel_i[cus_ind]
                    while dis_split>0
                        workload_n[cur_cus] = workload_n[cur_cus] + min(Int(floor(pbm.workNeeded[cur_cus]/discr_step))-1, dis_split)
                        dis_split = dis_split - min(Int(floor(pbm.workNeeded[cur_cus]/discr_step))-1, dis_split)
                        cus_ind = cus_ind + 1
                        cur_cus = sel_i[cus_ind]
                        if cus_ind > sw
                            break
                        end
                    end
    
                    while dis_split>0
                        workload_n[cur_cus] = workload_n[cur_cus] + min(Int(ceil(pbm.workNeeded[cur_cus]/discr_step))-1, dis_split)
                        dis_split = dis_split - min(Int(ceil(pbm.workNeeded[cur_cus]/discr_step))-1, dis_split)
                        cus_ind = cus_ind + 1
                        if cus_ind > length(sel_i)
                            break
                        end
                        cur_cus = sel_i[cus_ind]
                    end

                    visitfs = []
                    for cc in clients
                        visitfs = append!(visitfs, [Visit(cc, min(workload_n[cc]*discr_step,pbm.workNeeded[cc]))]) 
                    end
                    total_travel_time = rr.cost
                    total_work_load_dis = sum(getHours.(visitfs))
                    totcost, rdcost = getRDCost(pbm, d,hh,visitfs,total_travel_time,total_work_load_dis,dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r)
                    newtsp_pp = PlanTSP_PP(d, total_travel_time, visitfs, total_work_load_dis, yes_set, totcost, rdcost+dual_added, indexrr)
                    append!(non_dominated_plans, [newtsp_pp])
                    if (rdcost < most_neg)
                        most_neg=rdcost
                    end
                end
            end
            ##!!!!!!!!!! Add part dealing with min(workload_n[cc]*discr_step,pbm.workNeeded[cc])) issue!!!!!!!!!!!!!!!

            #println(" Dual cost ", most_neg, " with LB ",rdcostLB)
        end
    end

    P = trimPlansPPL(non_dominated_plans) ####Remove additional routes with equal cost
    #equal to pricing problem
    com_add=0
    reduced_cost=[P[i].rdcost  for i in eachindex(P)]
 
    extended = [] # store newly generated plan
    idx_neg=sortperm(reduced_cost)[1:10] ## Select at most 10 negative columns
    for index in idx_neg
        if(reduced_cost[index]<-0.0000001)
            append!(indx,P[index].routeind)
            push!(x, @variable(model, lower_bound = 0))
            set_objective_coefficient(model, x[end], P[index].totcost)

            set_normalized_coefficient(con_veh[P[index].day], x[end], 1)

            h=zeros(Float64, pbm.n)
            visits = P[index].visits
            for visit in visits
                h[visit.client] = visit.hours
            end
            for i in 1:pbm.n # constraints  con_wrk
                set_normalized_coefficient(con_wrk[i], x[end], h[i])
            end
            
            # constraints con_ess
            set_normalized_coefficient(con_ess, x[end], sum(h[:]))

            totalTime = P[index].workloadD + P[index].cost
            OO = getOOtime(pbm, hh, totalTime,  P[index].cost) # to store overtime at each tier for each plan             
            for ww in 1:length(pbm.wages) # constraints  con_ovr
                set_normalized_coefficient(con_ovr[ww], x[end], OO[ww])
            end
            # constraints  con_cut
            set_normalized_coefficient(cut_r, x[end], P[index].in_set)
            
            com_add=com_add+1
            #println("Tot no. before ", length(non_dominated_plans), " after ", length(P), " Route ", index, " Rcost ", reduced_cost[index], " seq ", P[index].visits, " tottime ", totalTime, " tavel_time ", P[index].cost)
            ##clients = getClients(P[index])
            ##for cc in clients
                ##println("dual_con_wrk ", cc, " with ",dual_con_wrk[cc])
            ##end
            append!(extended, [PlanTSP(P[index].day, P[index].cost, visits)])
        else
            break
        end
    end

    #for pp in non_dominated_plans
        #println("Tot no. ", length(non_dominated_plans), " Route ", pp.visits, " tavel_time ", pp.cost)
    #end
    #println("！！Length ", length(R_set))
  
    return model, x, indx, extended, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, reduced_cost, com_add;
end
  
function RMP_addcolumnsPP_NoLB(model, pbm, indx, P_opt, R_set, x, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r,discr_step) 
    #Re-calculate the costs for all parameters
    Plans = [PlanTSP_PP(d, 0, [], 0, 0, 0, 0, 0) for d in 1:pbm.D] #Kai
    non_dominated_plans = []
    hh=vcat([0], [(pbm.wages[wa+1][2]-pbm.wages[wa][2])/(pbm.wages[wa+1][1]-pbm.wages[wa][1]) for wa in 1:(length(pbm.wages)-1)],[pbm.maxHours*2]) # get breakpoints of functions
    most_neg = 0 ## most negative reduced cost.
 
    order_c = reverse(sortperm(dual_con_wrk))
    # no need to use dominance rule?
    for d in 1:pbm.D
        A_d = findall(x->x>0,pbm.clientDays[:,d])
 
        for indexrr in eachindex(R_set)  ### Change this to tree?
            dual_added=0
            yes_set = 0
            if !(indexrr in P_opt)
                dual_added=-dual_cut_r
                yes_set =1
            end
            
            rr= R_set[indexrr]
            clients = getClients(rr)
            if !issubset(clients, A_d)
                continue
            end
            dis_total = Int(floor((pbm.maxHours-rr.cost)/discr_step))+length(clients) # +length(clients) Number of discretized time steps that can be added=needs the number of cusstomers
    
            if length(clients) > dis_total
                continue
            end     

            sel_i = intersect(order_c, clients) # rank customers to add.

            ## Compute the LB of a route and remove it if less than incumbent
            rdcostLB = getRDCostLB(pbm,d, hh, sel_i, rr.cost, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r, discr_step)
            
 
            # The first plan
            workload_n = ones(pbm.n) # workload assgined to customers
            visitfs = []
            for cc in clients
                visitfs = append!(visitfs, [Visit(cc, workload_n[cc]*discr_step)]) 
            end
            total_travel_time = rr.cost
            total_work_load_dis = sum(getHours.(visitfs))
            totcost, rdcost = getRDCost(pbm, d,hh,visitfs,total_travel_time,total_work_load_dis,dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r)
            newtsp_pp = PlanTSP_PP(d, total_travel_time, visitfs, total_work_load_dis, yes_set, totcost, rdcost+dual_added, indexrr)
            append!(non_dominated_plans, [newtsp_pp])

            # ranking customers by w_j from highest to lowest then assign by order.
            dis_split = length(clients) + 1
            cus_ind = 1
            cur_cus = sel_i[cus_ind]
            while dis_split<= dis_total                
                if workload_n[cur_cus]*discr_step > pbm.workNeeded[cur_cus]
                    cus_ind = cus_ind + 1
                end
              
                if cus_ind>length(sel_i)
                    break
                end
                cur_cus = sel_i[cus_ind]

                workload_n[cur_cus] = workload_n[cur_cus] + 1.0
                visitfs = []
                for cc in clients
                    visitfs = append!(visitfs, [Visit(cc, min(workload_n[cc]*discr_step,pbm.workNeeded[cc]))]) 
                end
                total_travel_time = rr.cost
                total_work_load_dis = sum(getHours.(visitfs))
                totcost, rdcost = getRDCost(pbm, d,hh,visitfs,total_travel_time,total_work_load_dis,dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r)
                newtsp_pp = PlanTSP_PP(d, total_travel_time, visitfs, total_work_load_dis, yes_set, totcost, rdcost+dual_added, indexrr)
                append!(non_dominated_plans, [newtsp_pp])
                if (rdcost < most_neg)
                    most_neg=rdcost
                end
                dis_split = dis_split+1
            end

            ##!!!!!!!!!! Add part dealing with min(workload_n[cc]*discr_step,pbm.workNeeded[cc])) issue!!!!!!!!!!!!!!!
            if length(sel_i)>1
                for sw in 1:(length(sel_i)-1)
                    dis_split = dis_total - length(clients)
                    workload_n = ones(pbm.n) 
                    cus_ind = 1
                    cur_cus = sel_i[cus_ind]
                    while dis_split>0
                        workload_n[cur_cus] = workload_n[cur_cus] + min(Int(floor(pbm.workNeeded[cur_cus]/discr_step))-1, dis_split)
                        dis_split = dis_split - min(Int(floor(pbm.workNeeded[cur_cus]/discr_step))-1, dis_split)
                        cus_ind = cus_ind + 1
                        cur_cus = sel_i[cus_ind]
                        if cus_ind > sw
                            break
                        end
                    end
    
                    while dis_split>0
                        workload_n[cur_cus] = workload_n[cur_cus] + min(Int(ceil(pbm.workNeeded[cur_cus]/discr_step))-1, dis_split)
                        dis_split = dis_split - min(Int(ceil(pbm.workNeeded[cur_cus]/discr_step))-1, dis_split)
                        cus_ind = cus_ind + 1
                        if cus_ind > length(sel_i)
                            break
                        end
                        cur_cus = sel_i[cus_ind]
                    end

                    visitfs = []
                    for cc in clients
                        visitfs = append!(visitfs, [Visit(cc, min(workload_n[cc]*discr_step,pbm.workNeeded[cc]))]) 
                    end
                    total_travel_time = rr.cost
                    total_work_load_dis = sum(getHours.(visitfs))
                    totcost, rdcost = getRDCost(pbm, d,hh,visitfs,total_travel_time,total_work_load_dis,dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r)
                    newtsp_pp = PlanTSP_PP(d, total_travel_time, visitfs, total_work_load_dis, yes_set, totcost, rdcost+dual_added, indexrr)
                    append!(non_dominated_plans, [newtsp_pp])
                    if (rdcost < most_neg)
                        most_neg=rdcost
                    end
                end
            end
            ##!!!!!!!!!! Add part dealing with min(workload_n[cc]*discr_step,pbm.workNeeded[cc])) issue!!!!!!!!!!!!!!!

            #println(" Dual cost ", most_neg, " with LB ",rdcostLB)
        end
    end

    P = trimPlansPPL(non_dominated_plans) ####Remove additional routes with equal cost
    #equal to pricing problem
    com_add=0
    reduced_cost=[P[i].rdcost  for i in eachindex(P)]
 
    extended = [] # store newly generated plan
    idx_neg=sortperm(reduced_cost)[1:10] ## Select at most 10 negative columns
    for index in idx_neg
        if(reduced_cost[index]<-0.0000001)
            append!(indx,P[index].routeind)
            push!(x, @variable(model, lower_bound = 0))
            set_objective_coefficient(model, x[end], P[index].totcost)

            set_normalized_coefficient(con_veh[P[index].day], x[end], 1)

            h=zeros(Float64, pbm.n)
            visits = P[index].visits
            for visit in visits
                h[visit.client] = visit.hours
            end
            for i in 1:pbm.n # constraints  con_wrk
                set_normalized_coefficient(con_wrk[i], x[end], h[i])
            end
            
            # constraints con_ess
            set_normalized_coefficient(con_ess, x[end], sum(h[:]))

            totalTime = P[index].workloadD + P[index].cost
            OO = getOOtime(pbm, hh, totalTime,  P[index].cost) # to store overtime at each tier for each plan             
            for ww in 1:length(pbm.wages) # constraints  con_ovr
                set_normalized_coefficient(con_ovr[ww], x[end], OO[ww])
            end
            # constraints  con_cut
            set_normalized_coefficient(cut_r, x[end], P[index].in_set)
            
            com_add=com_add+1
            #println("Tot no. before ", length(non_dominated_plans), " after ", length(P), " Route ", index, " Rcost ", reduced_cost[index], " seq ", P[index].visits, " tottime ", totalTime, " tavel_time ", P[index].cost)
            ##clients = getClients(P[index])
            ##for cc in clients
                ##println("dual_con_wrk ", cc, " with ",dual_con_wrk[cc])
            ##end
            append!(extended, [PlanTSP(P[index].day, P[index].cost, visits)])
        else
            break
        end
    end

    #for pp in non_dominated_plans
        #println("Tot no. ", length(non_dominated_plans), " Route ", pp.visits, " tavel_time ", pp.cost)
    #end
    #println("！！Length ", length(R_set))
  
    return model, x, indx, extended, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, reduced_cost, com_add;
end

function RMP_addcolumnsEE(model, pbm, P, x, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r, indx, P_opt) 
    #Re-calculate the costs for all parameters
    c = [getCost(p, pbm) for p in P]
    T_p =  [tottime(p, pbm) for p in P]
    hh=vcat([0], [(pbm.wages[wa+1][2]-pbm.wages[wa][2])/(pbm.wages[wa+1][1]-pbm.wages[wa][1]) for wa in 1:(length(pbm.wages)-1)],[pbm.maxHours*2]) # get breakpoints of functions
    OO=zeros(Float64, length(P),length(pbm.wages)) # to store overtime at each tier for each plan
    for pp in eachindex(P) #claculate the budget of each plan at each tier
        p = P[pp] 
        travel_time = p.cost
        totalTime = travel_time + getWorkTime(p)
        for ww in 1:length(pbm.wages)
            if totalTime > hh[ww+1]
                OO[pp,ww] = hh[ww+1] - hh[ww]
            elseif totalTime <= hh[ww]
                OO[pp,ww] = 0
            else
                OO[pp,ww] = totalTime - hh[ww]
            end
            Hour_overload = 0 # get rid of the travel time part
            if travel_time > hh[ww+1]
                Hour_overload = hh[ww+1] - hh[ww]
            elseif travel_time <= hh[ww]
                Hour_overload = 0
            else
                Hour_overload = travel_time - hh[ww]
            end
            OO[pp,ww] = OO[pp,ww] - Hour_overload
        end
    end
    h = getHoursClientInPlan(P, pbm);
    y = getDayInPlan(P, pbm);
    
    
    
    #equal to pricing problem
    com_add=0
    reduced_cost=zeros(length(P))

    for index in eachindex(P)
        if length(getClients(P[index]))>1
            reduced_cost[index]=c[index]-sum(dual_con_veh[d] * y[d,index] for d in 1:pbm.D)-sum((dual_con_wrk[i]+dual_con_ess) * h[i,index] for i=1:pbm.n)-sum(dual_con_ovr[ww] * OO[index,ww] for ww=1:length(pbm.wages))
            if !(indx[index] in P_opt)
                reduced_cost[index]=reduced_cost[index]-dual_cut_r
            end
        end

    end
    
    idx_neg=sortperm(reduced_cost)[1:10] ## Select at most 10 negative columns
    for index in idx_neg
        if(reduced_cost[index]<-0.0000001)
             
            push!(x, @variable(model, lower_bound = 0))
            set_objective_coefficient(model, x[end], c[index])

            for d in 1:pbm.D # constraints  con_veh
                set_normalized_coefficient(con_veh[d], x[end], y[d,index])
            end

            for i in 1:pbm.n # constraints  con_wrk
                set_normalized_coefficient(con_wrk[i], x[end], h[i,index])
            end
            
            # constraints con_ess
            set_normalized_coefficient(con_ess, x[end], sum(h[:,index]))

            for ww in 1:length(pbm.wages) # constraints  con_ovr
                set_normalized_coefficient(con_ovr[ww], x[end], OO[index,ww])
            end

            # constraints  con_cut
            set_normalized_coefficient(cut_r, x[end], 1)
            
            com_add=com_add+1
            println("Tot no. ", length(P), " Route ", index, " Rcost ", reduced_cost[index], " seq ", P[index].visits, " tottime ", (P[index].cost+sum(h[:,index])), " tavel_time ", P[index].cost, " MAX ", pbm.maxHours)

            clients = getClients(P[index])
            for cc in clients
                println("Workload ass ", cc, " with ",pbm.workNeeded[cc], " with dual ", dual_con_wrk[cc])
            end
        else
            break
        end
    end
 
    return model, x, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, reduced_cost, com_add;
end

function optSPAlg_CGIP(model, indx, time_limit)
    if time_limit > 0
        set_optimizer_attribute(model, "TimeLimit", time_limit)
    end
 
    xx = all_variables(model)

    @suppress optimize!(model);

    optimal_objective, gap, lower_bound = termination(model)
    #optimal_objective=objective_value(model)
    #gap=0; lower_bound=optimal_objective

    #P_opt = getOptimalPlans(pbm, model, "SP", P=P)
    Opt_route =[]

    Opt_route = getOptimalRoutes(model, indx) # get the set of routes positive
    P_opt = unique(Opt_route)

    # A warmup
    if Opt_route!=[]
        x_solution = value.(xx)
    end
    #r_opt =[]
    #xr_opt = value.(model[:xr])
    #for iir in 1:length(xr_opt)
        #if xr_opt[iir]>0.1
            #append!(r_opt,  iir) 
        #end
    #end
    #println("Verfied: ",r_opt)

    return model, optimal_objective, gap, lower_bound, P_opt, x_solution;
end
#### CG Procedure to solve SP

function solver(pbm; method="Hybrid", Optimizer=Gurobi.Optimizer, max_len_visits=3, discr_step=1., maxTime=1800, LogFile=nothing, front_loaded=false, λ=1, μ=1)
    # front_loading means optimizing to finish jobs as early as possible. Only available for "Hybrid" and used mostly on FarmWise data.
    No_iter = 1
    if method == "Hybrid"
        start_time = time()
        println("Time remaining for plan generation: $maxTime")
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, max_len_visits=max_len_visits)
        println("Plan generation time: $(time()-start_time)")
        time_left = remaining_time(start_time, maxTime) 
        println("Time remaining for solve: $time_left")
        IP_time = @elapsed model, optimal_objective, gap, lower_bound, P_opt = solveHybrid(pbm, P, Optimizer, time_left, LogFile, front_loaded, λ, μ) 
        n_P = length(P)
        println("Solve time: $IP_time")
        solving_time = time() - start_time
    elseif method == "SP"
        start_time = time()
        println("Time remaining for plan generation: $maxTime")
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=max_len_visits, discr_step=discr_step)
        println("Plan generation time: $(time()-start_time)")
        time_left = remaining_time(start_time, maxTime) 
        println("Time remaining for solve: $time_left")
        IP_time = @elapsed model, optimal_objective, gap, lower_bound, P_opt = solveSP(pbm, P, Optimizer, time_left, LogFile)
        n_P = length(P)
        println("Solve time: $IP_time")
        solving_time = time() - start_time

    elseif method == "SP_Ben"
        start_time = time()
        println("Time remaining for plan generation: $maxTime")
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=max_len_visits, discr_step=discr_step) 
        println("Plan generation time: $(time()-start_time)")

        time_left = remaining_time(start_time, maxTime) 
        println("Time remaining to solve SP: $time_left")
        solving_time0 = @elapsed model, optimal_objective, gap, lower_bound, P_opt = solveSP(pbm, P, Optimizer, max(time_left,100), LogFile)
        n_P = length(P)
        println("SP solving time, ", solving_time0, " Obj ", optimal_objective)
        time_left = remaining_time(start_time, maxTime) 
        println("Time remaining to optimize workload: $time_left")
        solving_time1 = @elapsed model, optimal_objective, gap, lower_bound, P_opt = solveHybridSP(pbm, P_opt, Optimizer, max(time_left,100), LogFile, front_loaded, λ, μ) 
        println("Workload optimization time: $solving_time1")
        IP_time=solving_time0+solving_time1
        solving_time = time() - start_time

    elseif method == "Classic"
        solving_time = @elapsed model, optimal_objective, gap, lower_bound, P_opt = solveClassic(pbm, Optimizer, maxTime, max_len_visits, LogFile)
        DP_time, IP_time, P, n_P = 0, solve_time(model), Vector{Plan}(), 0

    elseif method == "SP_Alg"
        start_time = time()
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=max_len_visits, discr_step=discr_step) 
        println("Plan generation time: $DP_time")
        n_P = length(P)
        UB = 9999999; LB = 0; iter = 1; Routes = []; P_opt=[]; x_solution=[]; IP_time =0; Best_P_opt = Vector{Plan}() #Initialization

        time_left = remaining_time(start_time, maxTime)
        println("Time remaining for model construction: $time_left")
        construction_time = @elapsed model, cut_r, x = @suppress modelSPAlg(pbm, P, Optimizer, LogFile, method, discr_step) 
        println("model construction time: ", construction_time)
        
        search_step = 1
        while 1==1
            println("""

            =====================
            EXACT METHOD: ITERATION $iter
            =====================
            """)
            time_left = remaining_time(start_time, maxTime)
            time_left == 0. && break
            println("Time remaining for LB solve: $time_left")
            solving_time = @elapsed model, LB, gap, bound, P_opt, x_solution = @suppress optSPAlg(model, cut_r, x, indx, P_opt, x_solution, time_left) 
            println("Solving time of LB model ", solving_time, " with LB ", LB, " Sol. len ", length(P_opt))
   
            if P_opt==[] ##
                println("The problem is infeasible")
                break
            end
            
            append!(Routes,P_opt) ## capture unique routes
            Routes=unique(Routes)
            println("Explored $(length(Routes))/$(length(R_set)) routes")
            Route_set,P_opt=extendRoutes(Routes, R_set, pbm) ## expend routes to days

            #for indexrr in eachindex(Route_set)
                #println("Route ", indexrr," is ",Route_set[indexrr])
            #end
            
            time_left = remaining_time(start_time, maxTime)
            time_left == 0. && break
            println("Time remaining for UB solve: $time_left")
            solving_time = @elapsed model1, optimal_objective1, gap1, bound1, P_opt1 = @suppress solveHybridAlg(pbm, Route_set, Optimizer, time_left, LogFile, front_loaded, λ, μ, P_opt)
            println("Solving time of UB model = $solving_time")
            IP_time += solving_time
            if optimal_objective1<UB
                UB=optimal_objective1
                Best_P_opt=P_opt1
            end

            println("UB ", UB, " LB ", LB, " Gap ", (UB-LB)/LB, " Iter ", iter, " Length ", length(P), " New Sol ", optimal_objective1, " Step ", search_step)
            iter = iter + 1

            if iter > 30 
                println("STOP: more than 30 iterations")
                break
            end

            if remaining_time(start_time, maxTime) == 0.
                println("Time limit reached during exact method: time= $(time() - start_time) > $maxTime -- no more iterations")
                break
            end
            
            if (UB-LB)/LB <0.01
                println("Gap is <1% and search step=1 : STOP")
                    break
            end
            set_normalized_rhs(cut_r, search_step)
        end
  
        if ! (@isdefined UB)
            UB = Inf
            P_opt = []
            No_iter = 0
        else
            P_opt=Best_P_opt
            No_iter=iter-1
        end
        gap = (UB-LB)/LB
        lower_bound = LB
        optimal_objective =  UB
        solving_time= time() - start_time
        println("The final UB is ", UB)
    elseif method == "SP_Alg_CG" ## Alg_CG with Step improve acceleration
        start_time = time()
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=1, discr_step=discr_step) 
        println("Plan generation time: $DP_time")
        n_P = length(P)
        UB = 9999999; LB = 0; iter = 1; Routes = []; P_opt=[]; x_solution=[]; IP_time =0; Best_P_opt = Vector{Plan}() #Initialization
        Step_ratio =0.8 

        time_left = remaining_time(start_time, maxTime)
        println("Time remaining for model construction: $time_left")
        construction_time = @elapsed model, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x, c, y, h, OO = @suppress RMP_modelSPAlg(pbm, P, Optimizer, LogFile, method, discr_step) 
        println("model construction time: ", construction_time)
        time_left = remaining_time(start_time, maxTime)

        ###Re-generate plans！！！！！！！！！！！！To be deleted
        P1 = P; indx1 = indx
        method="Hybrid"
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=max_len_visits, discr_step=discr_step) 
        println("Plan re-generation time: $DP_time", " Set ",indx, " length P ",length(P), " P1 ", length(P1))
        P = P1; indx = indx1
        append!(indx,-1) ; append!(P,[PlanTSP(-1, 0, [Visit(-1,0)])]) ### This is to include dummy plan

        search_step = 1
        while 1==1
            println("""

            =====================
            EXACT METHOD: ITERATION $iter
            =====================
            """)
            time_left = remaining_time(start_time, maxTime)
            time_left == 0. && break
            println("Time remaining for LB solve: $time_left")
            LB_true=0
            #####A CG-Based Algorithm
            com_add = 1
            iter1 = 0
            while com_add!=0
                Rmaster_time = @elapsed model, LB, x_solution, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r = @suppress RMP_optSPAlg(model, pbm, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x_solution) 
                Pricing_time = @elapsed model, x, indx, extended, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, reduced_cost, com_add =  @suppress RMP_addcolumnsPP(model, pbm, indx, P_opt, R_set, x, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r,discr_step) 
                append!(P,extended)
                iter1=iter1+1; LB_true=LB
                #println("Obj ",LB, " Most neg reduced cost is ",minimum(reduced_cost), " with added cols ", com_add, " at iteration ", iter)
                if iter1 > 1000 ###1000
                    println("Iterations break in column generation")
                    break
                end
            end
            println("Columns in the pool ", length(P), " with CG iterations ", iter1, " at iteartion ", iter)

            for index in eachindex(x)
                set_integer(x[index])
            end
            solving_time = @elapsed model, LB, gap, bound, P_opt, x_solution = @suppress optSPAlg_CGIP(model, indx, time_left) 
            for index in eachindex(x)
                unset_integer(x[index])
            end
            #####A CG-Based Algorithm
 
            if (LB_true>=99999999)&&(iter>=1)
                LB = UB
                println("Routes all explored, best LB")
                break
            end

            println("Solving time of LB-IP model ", solving_time, " with LB-IP ", LB, " LB_CG ", LB_true)
            if P_opt==[] ### revise stepwise
                if search_step<=1
                    println("UNKNOWN STOP")
                    break
                end
                search_step = max(search_step/4,1)#was "search_step/2" search_step*Step_ratio
                set_normalized_rhs(cut_r, search_step)
                println("Step has been revised to $search_step, recomputing lower bound")
                continue
            end
            if (iter==1) ## initial stepwise
                search_step =  length(P_opt)/2
                set_normalized_rhs(cut_r, search_step) #########Stepwise for enlarge /2
                println("Step is initialized to ", search_step)
            else # shrink the stepwise
                search_step = max(search_step*Step_ratio,1) #####search_step = max(search_step*0.5,1)
                set_normalized_rhs(cut_r, search_step)
                println("Step has been revised to ", search_step)
            end
             
            append!(Routes,P_opt) ## capture unique routes
            Routes=unique(Routes)
            println("Explored $(length(Routes))/$(length(R_set)) routes")
            Route_set,P_opt=extendRoutes(Routes, R_set, pbm) ## expend routes to days

            for index in eachindex(x) # change the coefficient
                if indx[index] in P_opt
                    set_normalized_coefficient(cut_r, x[index], 0)
                end
            end
            #for indexrr in eachindex(Route_set)
                #println("Route ", indexrr," is ",Route_set[indexrr])
            #end

            time_left = remaining_time(start_time, maxTime)
            time_left == 0. && break
            println("Time remaining for UB solve: $time_left")
            solving_time = @elapsed model1, optimal_objective1, gap1, bound1, P_opt1 = @suppress solveHybridAlg(pbm, Route_set, Optimizer, time_left, LogFile, front_loaded, λ, μ, P_opt)
            println("Solving time of UB model = $solving_time")
            IP_time += solving_time
            if optimal_objective1<UB
                UB=optimal_objective1
                Best_P_opt=P_opt1
            end

            println("UB ", UB, " LB ", LB, " Gap ", (UB-LB)/LB, " LB_CG ", LB_true, " Gap-CG ", (UB-LB_true)/LB_true, " Iter ", iter, " Length ", length(P), " New Sol ", optimal_objective1, " Step ", search_step)
            iter = iter + 1
            
            if (UB >= 9999999) ## no feasible solution upon termination
                if iter > 8#was 8
                    println("No feasible solutions by Heu Alg!")
                    break
                end
                search_step = search_step/Step_ratio
                set_normalized_rhs(cut_r, search_step)
                println("More iterations: Step has been revised to ", search_step)
                continue
            end

            if iter > 8#was 8
                println("Reached iteration maximum")
                break
            end

            if remaining_time(start_time, maxTime) == 0.
                println("Time limit reached during exact method: time= $(time() - start_time) > $maxTime -- no more iterations")
                break
            end
            
            if (UB-LB)/LB <0.01
                println("Gap is <1% and search step=1 : STOP")
                break
            end
        end
  
        if ! (@isdefined UB)
            UB = Inf
            P_opt = []
            No_iter = 0
        else
            P_opt=Best_P_opt
            No_iter=iter-1
        end
        gap = (UB-LB)/LB
        lower_bound = LB
        optimal_objective =  UB
        solving_time= time() - start_time
        println("The final UB is ", UB)
    elseif method == "SP_Alg_CG0" ## CG in the whole E&E # below codes, newly designed for CG to solve relaxation model
        start_time = time()
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=1, discr_step=discr_step) 
        println("Plan generation time: $DP_time")
        n_P = length(P)
        UB = 9999999; LB = 0; iter = 1; Routes = []; P_opt=[]; x_solution=[]; IP_time =0; Best_P_opt = Vector{Plan}() #Initialization

        time_left = remaining_time(start_time, maxTime)
        println("Time remaining for model construction: $time_left")
        construction_time = @elapsed model, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x, c, y, h, OO = @suppress RMP_modelSPAlg(pbm, P, Optimizer, LogFile, method, discr_step) 
        println("model construction time: ", construction_time)
        time_left = remaining_time(start_time, maxTime)

        ###Re-generate plans！！！！！！！！！！！！To be deleted
        P1 = P; indx1 = indx
        method="Hybrid"
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=max_len_visits, discr_step=discr_step) 
        println("Plan re-generation time: $DP_time", " Set ",indx, " length P ",length(P), " P1 ", length(P1))
        P = P1; indx = indx1
        append!(indx,-1) ; append!(P,[PlanTSP(-1, 0, [Visit(-1,0)])]) ### This is to include dummy plan

        search_step = 1
        while 1==1
            println("""

            =====================
            EXACT METHOD: ITERATION $iter
            =====================
            """)
            time_left = remaining_time(start_time, maxTime)
            time_left == 0. && break
            println("Time remaining for LB solve: $time_left")
            LB_true=0
            #####A CG-Based Algorithm
            com_add = 1
            iter1 = 0
            while com_add!=0
                Rmaster_time = @elapsed model, LB, x_solution, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r = @suppress RMP_optSPAlg(model, pbm, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x_solution) 
                Pricing_time = @elapsed model, x, indx, extended, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, reduced_cost, com_add =  @suppress RMP_addcolumnsPP(model, pbm, indx, P_opt, R_set, x, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r,discr_step) 
                append!(P,extended)
                iter1=iter1+1; LB_true=LB
                #println("Obj ",LB, " Most neg reduced cost is ",minimum(reduced_cost), " with added cols ", com_add, " at iteration ", iter)
                if iter1 > 1000 ###1000
                    println("Iterations break in column generation")
                    break
                end
            end
            println("Columns in the pool ", length(P), " with CG iterations ", iter1, " at iteartion ", iter)

            for index in eachindex(x)
                set_integer(x[index])
            end
            solving_time = @elapsed model, LB, gap, bound, P_opt, x_solution = @suppress optSPAlg_CGIP(model, indx, time_left) 
            for index in eachindex(x)
                unset_integer(x[index])
            end
            #####A CG-Based Algorithm

            if (LB_true>=99999999)&&(iter>=1)
                LB = UB
                println("Routes all explored, best LB")
                break
            end
 
            println("Solving time of LB-IP model ", solving_time, " with LB-IP ", LB, " LB_CG ", LB_true)
            if P_opt==[] ##
                println("The problem is infeasible")
                break
            end
             
            append!(Routes,P_opt) ## capture unique routes
            Routes=unique(Routes)
            println("Explored $(length(Routes))/$(length(R_set)) routes")
            Route_set,P_opt=extendRoutes(Routes, R_set, pbm) ## expend routes to days

            for index in eachindex(x) # change the coefficient
                if indx[index] in P_opt
                    set_normalized_coefficient(cut_r, x[index], 0)
                end
            end
            #for indexrr in eachindex(Route_set)
                #println("Route ", indexrr," is ",Route_set[indexrr])
            #end

            time_left = remaining_time(start_time, maxTime)
            time_left == 0. && break
            println("Time remaining for UB solve: $time_left")
            solving_time = @elapsed model1, optimal_objective1, gap1, bound1, P_opt1 = @suppress solveHybridAlg(pbm, Route_set, Optimizer, time_left, LogFile, front_loaded, λ, μ, P_opt)
            println("Solving time of UB model = $solving_time")
            IP_time += solving_time
            if optimal_objective1<UB
                UB=optimal_objective1
                Best_P_opt=P_opt1
            end

            println("UB ", UB, " LB ", LB, " Gap ", (UB-LB)/LB, " LB_CG ", LB_true, " Gap-CG ", (UB-LB_true)/LB_true, " Iter ", iter, " Length ", length(P), " New Sol ", optimal_objective1, " Step ", search_step)
            iter = iter + 1
            
            if iter > 30 
                println("STOP: more than 30 iterations")
                break
            end

            if remaining_time(start_time, maxTime) == 0.
                println("Time limit reached during exact method: time= $(time() - start_time) > $maxTime -- no more iterations")
                break
            end
            
            if (UB-LB)/LB <0.01
                println("Gap is <1% and search step=1 : STOP")
                    break
            end
            set_normalized_rhs(cut_r, search_step)
        end
  
        if ! (@isdefined UB)
            UB = Inf
            P_opt = []
            No_iter = 0
        else
            P_opt=Best_P_opt
            No_iter=iter-1
        end
        gap = (UB-LB)/LB
        lower_bound = LB
        optimal_objective =  UB
        solving_time= time() - start_time
        println("The final UB is ", UB)
    elseif method == "SP_LB"
        start_time = time()
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=max_len_visits, discr_step=discr_step) 
        println("Plan generation time: $DP_time")
        n_P = length(P)
        UB = 9999999; LB = 0; iter = 1; Routes = []; P_opt=[]; x_solution=[]; IP_time =0; Best_P_opt = Vector{Plan}() #Initialization

        time_left = remaining_time(start_time, maxTime)
        println("Time remaining for model construction: $time_left")
        construction_time = @elapsed model, cut_r, x = @suppress modelSPAlg(pbm, P, Optimizer, LogFile, method, discr_step) 
        println("model construction time: ", construction_time)
        time_left = remaining_time(start_time, maxTime)

        println("Time remaining for LB solve: $time_left")
        solving_time = @elapsed model, LB, gap, bound, P_opt, x_solution = @suppress optSPAlg(model, cut_r, x, indx, P_opt, x_solution, time_left) 
        println("Solving time of UB model ", solving_time, " with UB ", LB, " Sol. len ", length(P_opt))

        if ! (@isdefined UB)
            UB = Inf
            P_opt = []
            No_iter = 0
        else
            P_opt=Best_P_opt
            No_iter=0
        end
        No_iter = 0

        UB = LB
        gap = (UB-LB)/LB
        lower_bound = LB
        optimal_objective =  UB
        solving_time= time() - start_time
    elseif method == "SP_LB_CG"
        start_time = time()
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=1, discr_step=discr_step) 
        println("Plan generation time: $DP_time")
        n_P = length(P)
        UB = 9999999; LB = 0; iter = 1; Routes = []; P_opt=[]; x_solution=[]; IP_time =0; Best_P_opt = Vector{Plan}() #Initialization

        time_left = remaining_time(start_time, maxTime)
        println("Time remaining for model construction: $time_left")
        construction_time = @elapsed model, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x, c, y, h, OO = @suppress RMP_modelSPAlg(pbm, P, Optimizer, LogFile, method, discr_step) 
        println("model construction time: ", construction_time)
        time_left = remaining_time(start_time, maxTime)

        ###Re-generate plans！！！！！！！！！！！！To be deleted
        P1 = P; indx1 = indx
        method="Hybrid"
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=max_len_visits, discr_step=discr_step) 
        println("Plan re-generation time: $DP_time", " Set ",indx, " length P ",length(P), " P1 ", length(P1))
        P = P1; indx = indx1
        append!(indx,-1) ; append!(P,[PlanTSP(-1, 0, [Visit(-1,0)])]) ### This is to include dummy plan
 
        println("Time remaining for LB solve: $time_left")
        #####A CG-Based Algorithm
        com_add = 1
        iter1 = 0
        while com_add!=0
            Rmaster_time = @elapsed model, LB, x_solution, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r = @suppress RMP_optSPAlg(model, pbm, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x_solution) 
            Pricing_time = @elapsed model, x, indx, extended, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, reduced_cost, com_add =  @suppress RMP_addcolumnsPP(model, pbm, indx, P_opt, R_set, x, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r,discr_step) 
            append!(P,extended)
            iter1=iter1+1
            println("Obj ",LB, " Most neg reduced cost is ",minimum(reduced_cost), " with added cols ", com_add, " at iteration ", iter, " dual_cut_r val ", dual_cut_r)
            if iter1 > 1000 ###1000
                println("Iterations break in column generation")
                break
            end
        end
        
        for index in eachindex(x)
            set_integer(x[index])
        end
        solving_time = @elapsed model, UB, gap, bound, P_opt, x_solution = @suppress optSPAlg_CGIP(model, indx, time_left) 
        #for index in eachindex(x)
            #unset_integer(x[index])
        #end
        #####A CG-Based Algorithm
        println("Solving time of UB model ", solving_time, " with UB ", UB, " Sol. len ", length(P_opt))
        
        if ! (@isdefined UB)
            UB = Inf
            P_opt = []
            No_iter = 0
        else
            P_opt=Best_P_opt
            No_iter=iter-1
        end
         
        No_iter = iter1
        gap = (UB-LB)/LB
        lower_bound = LB
        optimal_objective =  UB
        solving_time= time() - start_time
    elseif method == "SP_LB_CG_NoLB" # the CG algorithm if we do not use the lower bounding for the reduced cost
        method = "SP_LB_CG"
        start_time = time()
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=1, discr_step=discr_step) 
        println("Plan generation time: $DP_time")
        n_P = length(P)
        UB = 9999999; LB = 0; iter = 1; Routes = []; P_opt=[]; x_solution=[]; IP_time =0; Best_P_opt = Vector{Plan}() #Initialization

        time_left = remaining_time(start_time, maxTime)
        println("Time remaining for model construction: $time_left")
        construction_time = @elapsed model, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x, c, y, h, OO = @suppress RMP_modelSPAlg(pbm, P, Optimizer, LogFile, method, discr_step) 
        println("model construction time: ", construction_time)
        time_left = remaining_time(start_time, maxTime)

        ###Re-generate plans！！！！！！！！！！！！To be deleted
        P1 = P; indx1 = indx
        method="Hybrid"
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=max_len_visits, discr_step=discr_step) 
        println("Plan re-generation time: $DP_time", " Set ",indx, " length P ",length(P), " P1 ", length(P1))
        P = P1; indx = indx1
        append!(indx,-1) ; append!(P,[PlanTSP(-1, 0, [Visit(-1,0)])]) ### This is to include dummy plan
 
        println("Time remaining for LB solve: $time_left")
        #####A CG-Based Algorithm
        com_add = 1
        iter1 = 0
        while com_add!=0
            Rmaster_time = @elapsed model, LB, x_solution, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r = @suppress RMP_optSPAlg(model, pbm, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x_solution) 
            Pricing_time = @elapsed model, x, indx, extended, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, reduced_cost, com_add =  @suppress RMP_addcolumnsPP_NoLB(model, pbm, indx, P_opt, R_set, x, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r,discr_step) 
            append!(P,extended)
            iter1=iter1+1
            println("Obj ",LB, " Most neg reduced cost is ",minimum(reduced_cost), " with added cols ", com_add, " at iteration ", iter, " dual_cut_r val ", dual_cut_r)
            if iter1 > 1000 ###1000
                println("Iterations break in column generation")
                break
            end
        end

        for index in eachindex(x)
            set_integer(x[index])
        end
        solving_time = @elapsed model, UB, gap, bound, P_opt, x_solution = @suppress optSPAlg_CGIP(model, indx, time_left) 
        #for index in eachindex(x)
            #unset_integer(x[index])
        #end
        #####A CG-Based Algorithm
        println("Solving time of UB model ", solving_time, " with UB ", UB, " Sol. len ", length(P_opt))

        if ! (@isdefined UB)
            UB = Inf
            P_opt = []
            No_iter = 0
        else
            P_opt=Best_P_opt
            No_iter=iter-1
        end
         
        No_iter = iter1
        gap = (UB-LB)/LB
        lower_bound = LB
        optimal_objective =  UB
        solving_time= time() - start_time
    elseif method == "SP_LB_CG_with_E" ##enumerate all plans at the begining: To be deleted
        start_time = time()
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=1, discr_step=discr_step) 
        println("Plan generation time: $DP_time")
        n_P = length(P)
        UB = 9999999; LB = 0; iter = 1; Routes = []; P_opt=[]; x_solution=[]; IP_time =0; Best_P_opt = Vector{Plan}() #Initialization

        time_left = remaining_time(start_time, maxTime)
        println("Time remaining for model construction: $time_left")
        construction_time = @elapsed model, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x, c, y, h, OO = @suppress RMP_modelSPAlg(pbm, P, Optimizer, LogFile, method, discr_step) 
        println("model construction time: ", construction_time)
        time_left = remaining_time(start_time, maxTime)

        ###Re-generate plans！！！！！！！！！！！！To be deleted
        DP_time = @elapsed P, R_set, indx = getAllPlansDP(pbm, method=method, max_len_visits=max_len_visits, discr_step=discr_step) 
        println("Plan re-generation time: $DP_time")
 
        println("Time remaining for LB solve: $time_left")
        #####A CG-Based Algorithm
        com_add = 1
        iter = 0
        while com_add!=0
            Rmaster_time = @elapsed model, LB, x_solution, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r = @suppress RMP_optSPAlg(model, pbm, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, x_solution) 
            Pricing_time = @elapsed model, x, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, reduced_cost, com_add = @suppress RMP_addcolumnsEE(model, pbm, P, x, con_veh, con_wrk, con_ess, con_ovr, con_dut, cut_r, dual_con_veh, dual_con_wrk, dual_con_ess, dual_con_ovr, dual_con_dut, dual_cut_r, indx, P_opt) 
            iter=iter+1
            println("Obj ",LB, " Most neg reduced cost is ",minimum(reduced_cost), " with added cols ", com_add, " at iteration ", iter)
            if iter > 1000 ###1000
                println("Iterations break in column generation")
                break
            end
        end

        for index in eachindex(x)
            set_integer(x[index])
        end
        solving_time = @elapsed model, UB, gap, bound, P_opt, x_solution = @suppress optSPAlg_CGIP(model, indx, time_left)
        #for index in eachindex(x)
            #unset_integer(x[index])
        #end
        #####A CG-Based Algorithm

        println("Solving time of UB model ", solving_time, " with UB ", UB, " Sol. len ", length(P_opt))

        if ! (@isdefined UB)
            UB = Inf
            P_opt = []
            No_iter = 0
        else
            P_opt=Best_P_opt
            No_iter=iter-1
        end
         
        No_iter = iter
        gap = (UB-LB)/LB
        lower_bound = LB
        optimal_objective =  UB
        solving_time= time() - start_time
    else
        throw(ArgumentError("Please use one of the following methods: 'Hybrid', 'SP', 'SP_Alg', 'SP_Ben', 'SP_Ben' or 'Classic'"))
    end

    c0 = [getCost(p, pbm) for p in P_opt]
    c1 = [getCost_Linear(p, pbm) for p in P_opt]
    field_per_route = [length(getClients(p))  for p in P_opt]
    route_per_field = zeros(Int,pbm.n)
    for p in P_opt  
        for cus in getClients(p)
            route_per_field[cus]=route_per_field[cus]+1
        end
    end
    Tra_time = [getTravelTime(p, pbm)  for p in P_opt]
    Work_time = [getWorkTime(p)  for p in P_opt]
 
    full_sharing =false
    for client in 1:pbm.n
        if (route_per_field[client]>1) 
            for p in P_opt
                if (client in getClients(p))& (length(getClients(p))>1)
                    full_sharing=true
                end
            end
        end
    end

    results = Dict(
                    "model" => model,
                    "obj" => optimal_objective,
                    "gap" => gap,
                    "lower_bound" => lower_bound,
                    "DP_time" => DP_time,
                    "IP_time" => IP_time,
                    "solving_time" => solving_time,
                    "n_plans" => n_P,
                    "P" => P,
                    "solution" => P_opt,
                    "iterations" => No_iter,
                    "Avg working hours" => mean(Work_time),
                    "Avg traveling hours" => mean(Tra_time),
                    "full_sharing" => full_sharing,
                    "Avg plans per field" => mean(route_per_field),
                    "Avg fileds per plan" => mean(field_per_route),
                    "Linear cost obj/obj" => sum(c1)/sum(c0)
        )            
    
    #println(mean(Work_time)," ",mean(Tra_time)," ",mean(route_per_field)," ",mean(field_per_route)," ",sum(c1)/sum(c0))
    return results
end


"""
    returns the time limit given max_time and start time (checks the current time)
"""
remaining_time(start_time, max_time) = max(0., max_time + start_time - time())
